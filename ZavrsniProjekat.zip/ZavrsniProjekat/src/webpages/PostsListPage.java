package webpages;

import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class PostsListPage {

	private WebDriver driver;
	private WebDriverWait driverWait;
	private static final String PAGE_URl = "https://testblog.kurs-qa.cubes.edu.rs/admin/posts";
	
	//WebElements
	@FindBy(name="title")
	private WebElement weTitle;
	
	@FindBy(xpath="//span[text()='--Choose Author --']")
	private WebElement weAuthor;
	
	@FindBy(xpath="//span[text()='--Choose Category --']")
	private WebElement weCategory;
	
	@FindBy(name="important")
	private WebElement weImportant;
	
	@FindBy(name="status")
	private WebElement weStatus;
	
	@FindBy(xpath="//input[@type='search']")
	private WebElement weWithTag;
	
	@FindBy(name="entities-list-table_length")
	private WebElement weShowEntries;
	
	@FindBy(xpath="//input[@class='form-control form-control-sm']")
	private WebElement weSearch;
	
	@FindBy(xpath="//i[@class='fas fa-eye']")
	private WebElement weViewPostButton;
	
	@FindBy(xpath="//i[@class='fas fa-edit']")
	private WebElement weUpdatePostButton;
	
	@FindBy(xpath="//i[@class='fas fa-trash']")
	private WebElement weDeletePostButton;
	
	@FindBy(xpath="//form[@id='delete-modal']//button[2]")
	private WebElement weDeleteButton;
	
	@FindBy(xpath="//form[@id='delete-modal']//button[text()='Cancel']")
	private WebElement weDeleteCancelButton;
	
	@FindBy(xpath="//form[@id='disable-modal']//button[text()='Cancel']")
	private WebElement weDisableCancelButton;
	
	@FindBy(xpath="//i[@class='fas fa-minus-circle']")
	private WebElement weDisablePostButton;
	
	@FindBy(xpath="//form[@id='disable-modal']//button[2]")
	private WebElement weDisableButton;
	
	@FindBy(xpath="//i[@class='fas fa-times']")
	private WebElement weUnimportantPostButton;
	
	@FindBy(xpath="//form[@id='unimportant-modal']//button[2]")
	private WebElement weUnimportantButton;
	
	@FindBy(xpath="//form[@id='unimportant-modal']//button[text()='Cancel']")
	private WebElement weUnimportantCancelButton;
	
	@FindBy(xpath="//i[@class='fas fa-bookmark']")
	private WebElement weImportantPostButton;
	
	@FindBy(xpath="//form[@id='important-modal']//button[2]")
	private WebElement weImportantButton;
	
	@FindBy(xpath="//form[@id='important-modal']//button[text()='Cancel']")
	private WebElement weImportantCancelButton;
	
	@FindBy(xpath="//i[@class='fas fa-check']")
	private WebElement weEnablePostButton;
	
	@FindBy(xpath="//form[@id='enable-modal']//button[2]")
	private WebElement weEnableButton;
	
	@FindBy(xpath="//form[@id='enable-modal']//button[text()='Cancel']")
	private WebElement weEnableCancelButton;
	
	@FindBy(xpath="//li[@id='entities-list-table_previous']//a")
	private WebElement wePreviousButton;
	
	@FindBy(xpath="//ul[@class='pagination']//li[2]//a")
	private WebElement wePage1;
	
	@FindBy(xpath="//ul[@class='pagination']//li[3]//a")
	private WebElement wePage2;
	
	@FindBy(xpath="//ul[@class='pagination']//li[4]//a")
	private WebElement wePage3;
	
	@FindBy(xpath="//li[@id='entities-list-table_next']//a")
	private WebElement weNextPageButton;
	
	@FindBy(xpath="//div[@class='card-tools']//a")
	private WebElement weAddNewPostButton;
	
	@FindBy(xpath="//a[@href='https://testblog.kurs-qa.cubes.edu.rs/admin']")
	private WebElement weHome;
	
	@FindBy(xpath="//i[@class='far fa-user']")
	private WebElement weProfile;
	
	@FindBy(xpath="//a[@href='https://testblog.kurs-qa.cubes.edu.rs/logout']")
	private WebElement weLogoutButton;
	
	@FindBy(xpath="//a[@class='nav-link']")
	private WebElement weNavigation;
	
	
	@FindBy(xpath="//td[text()='No matching records found']")
	private WebElement weNoMatchingRecordFoundMessage;
	
	@FindBy(xpath="//div[@class='toast-message']")
	WebElement weUpdateMessage;
	
	
	
	public PostsListPage(WebDriver driver, WebDriverWait driverWait) {
		this.driver = driver;
		this.driverWait=driverWait;
		this.driver.get(PAGE_URl);
		this.driver.manage().window().maximize();
		PageFactory.initElements(driver,this);
	}
	
	public void openPage() {
		this.driver.get(PAGE_URl);
	}
	
	public void title(String title) {
	
		weTitle.clear();
		weTitle.sendKeys(title);
	}
	
	public void author(String author) {

		weAuthor.click();
		WebElement we =driver.findElement(By.xpath("//option[text()='"+author+"']"));
		we.click();
        
	}
	
	public void category(String category) {
		
		weCategory.click();
		WebElement we =driver.findElement(By.xpath("//option[text()='"+category+"']"));
		we.click();
		
	}
	
	public void important(String text) {
		weImportant.click();
		WebElement we = driver.findElement(By.xpath("//option[text()='"+text+"']"));
		we.click();
	
	}
	
	public void status(String text) {
		weStatus.click();
		WebElement we = driver.findElement(By.xpath("//option[text()='"+text+"']"));
		we.click();
	}
	
	public void withTag(String tag) {
		weWithTag.clear();
		weWithTag.click();
		WebElement we = driver.findElement(By.xpath("//option[text()='"+tag+"']"));
		we.click();
	}
	
	public void showEntries(String entries) {
		weShowEntries.click();
		WebElement we = driver.findElement(By.xpath("//option[text()='"+entries+"']"));
		we.click();
	}
	
	public void search(String search) {
		weSearch.clear();
		weSearch.sendKeys(search);
	}
	
	public void viewPost() {
	
		driverWait.until(ExpectedConditions.visibilityOf(weViewPostButton));

		weViewPostButton.click();
	}
	
	
	public void updatePost() {
		
		driverWait.until(ExpectedConditions.visibilityOf(weUpdatePostButton));
		
		weUpdatePostButton.click();
	}
	
	public void deletePostButton() {
		
		
		driverWait.until(ExpectedConditions.visibilityOf(weDeletePostButton));
		
		weDeletePostButton.click();
	}
	
	public void deleteButton() {
		
		driverWait.until(ExpectedConditions.visibilityOf(weDeleteButton));
		
		weDeleteButton.click();
		
	}
	
	public void deleteCancelButton() {
		
		driverWait.until(ExpectedConditions.visibilityOf(weDeleteCancelButton));
		
		weDeleteCancelButton.click();
	}
	
	public void disablePostButton() {
		
	
		driverWait.until(ExpectedConditions.visibilityOf(weDisablePostButton));
		
		weDisablePostButton.click();
	}
	
	public void disableButton() {
		
		driverWait.until(ExpectedConditions.visibilityOf(weDisableButton));
		
		weDisableButton.click(); 
	}
	
	public void disableCancelButton() {
		
		driverWait.until(ExpectedConditions.visibilityOf(weDisableCancelButton));
		
		weDisableCancelButton.click();
	}
	
	
	public void setPostAsUnimportant() {
		
		driverWait.until(ExpectedConditions.visibilityOf(weUnimportantPostButton));
		
		weUnimportantPostButton.click();
		
	}
	
	public void unimportantButton() {
		
		driverWait.until(ExpectedConditions.visibilityOf(weUnimportantButton));
		
		weUnimportantButton.click(); 
	}
	
	public void unimportantCancelButton() {
		driverWait.until(ExpectedConditions.visibilityOf(weUnimportantCancelButton));
		
		weUnimportantCancelButton.click();
	}
	
	public void setPostAsImportant() {
		
		driverWait.until(ExpectedConditions.visibilityOf(weImportantPostButton));
		
		weImportantPostButton.click();
		
	}
	
	public void importantButton() {
		
		driverWait.until(ExpectedConditions.visibilityOf(weImportantButton));
		
		weImportantButton.click(); 
	}
	
	public void importantCancelButton() {
		
		driverWait.until(ExpectedConditions.visibilityOf(weImportantCancelButton));
		
		weImportantCancelButton.click();
	}
	
	public void enablePost() {
		
		
		driverWait.until(ExpectedConditions.visibilityOf(weEnablePostButton));
		
		weEnablePostButton.click();
		
	}
	
	public void enableButton() {
		
		driverWait.until(ExpectedConditions.visibilityOf(weEnableButton));
		
		weEnableButton.click();
	}
	
	public void enableCanCelButton() {
		
		driverWait.until(ExpectedConditions.visibilityOf(weEnableCancelButton));
		
		weEnableCancelButton.click();
		
		
	}
	
	
	
	public void home() {
		
		weHome.click();
	}
	
	public void addNewPost() {
		
		weAddNewPostButton.click();
	}
	
	public void logout() {
		
		weProfile.click();
		
		weLogoutButton.click();
	}
	
	public void navigation() {
		
		weNavigation.click();
	}
	
	public void nextPage() {
		
		
		
		driverWait.until(ExpectedConditions.visibilityOf(weNextPageButton));
	
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", weNextPageButton);
		
		JavascriptExecutor js = (JavascriptExecutor)driver;
		js.executeScript("arguments[0].click()", weNextPageButton);
	}
	
    public void page3() {
		
		
		
		driverWait.until(ExpectedConditions.visibilityOf(wePage2));
	
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", wePage3);
		
		JavascriptExecutor js = (JavascriptExecutor)driver;
		js.executeScript("arguments[0].click()", wePage2);
	}
	
    public void page2() {
		
		
		
		driverWait.until(ExpectedConditions.visibilityOf(wePage2));
	
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", wePage2);
		
		JavascriptExecutor js = (JavascriptExecutor)driver;
		js.executeScript("arguments[0].click()", wePage2);
	}
    
    public void page1() {
		
		
		
		driverWait.until(ExpectedConditions.visibilityOf(wePage1));
	
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", wePage1);
		
		JavascriptExecutor js = (JavascriptExecutor)driver;
		js.executeScript("arguments[0].click()", wePage1);
	}
    
    public void previousPage() {
		
		
		
		driverWait.until(ExpectedConditions.visibilityOf(wePreviousButton));
	
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", wePreviousButton);
		
		JavascriptExecutor js = (JavascriptExecutor)driver;
		js.executeScript("arguments[0].click()", wePreviousButton);
	}
	
    
    
    
    public String noMatchingRecordsMessage() {
    	
    	driverWait.until(ExpectedConditions.visibilityOf(weNoMatchingRecordFoundMessage));
    	
		return weNoMatchingRecordFoundMessage.getText();
	}
    
    public boolean isPostInList(String name) {
		
    	try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
    	
    	ArrayList<WebElement> wePosts = (ArrayList<WebElement>) driver.findElements(By.xpath("//td[text()='"+name+"']"));
		
		return !wePosts.isEmpty();
	
    }
    
    public boolean isPostInListAuthor(String name) {
		
    	try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
    	
    	ArrayList<WebElement> wePosts = (ArrayList<WebElement>) driver.findElements(By.xpath("//li[text()='"+name+"']"));
		
		return !wePosts.isEmpty();
	
    }
    
     public boolean isPostInListCategory(String name) {
		
    	try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
    	
    	ArrayList<WebElement> wePosts = (ArrayList<WebElement>) driver.findElements(By.xpath("//span[text()='"+name+"']"));
		
		return !wePosts.isEmpty();
	
    }
     
     public boolean isPostInListImportant(String name) {
 		
     	try {
 			Thread.sleep(2000);
 		} catch (InterruptedException e) {
 			// TODO Auto-generated catch block
 			e.printStackTrace();
 		}
     	
     	
     	ArrayList<WebElement> wePosts = (ArrayList<WebElement>) driver.findElements(By.xpath("//option[text()='"+name+"']"));
 		
 		return !wePosts.isEmpty();
 	
     }
     
     public boolean isPostInListStatus(String name) {
  		
      	try {
  			Thread.sleep(2000);
  		} catch (InterruptedException e) {
  			// TODO Auto-generated catch block
  			e.printStackTrace();
  		}
      	
      	
      	ArrayList<WebElement> wePosts = (ArrayList<WebElement>) driver.findElements(By.xpath("//option[text()='"+name+"']"));
  		
  		return !wePosts.isEmpty();
  	
      }
     

     public boolean isPostInListWithTag(String name) {
   		
       	try {
   			Thread.sleep(2000);
   		} catch (InterruptedException e) {
   			// TODO Auto-generated catch block
   			e.printStackTrace();
   		}
       	
       	
       	ArrayList<WebElement> wePosts = (ArrayList<WebElement>) driver.findElements(By.xpath("//li[text()='"+name+"']"));
   		
   		return !wePosts.isEmpty();
   	
       }
     
     public boolean entriesList(String name) {
 		
     	try {
 			Thread.sleep(2000);
 		} catch (InterruptedException e) {
 			// TODO Auto-generated catch block
 			e.printStackTrace();
 		}
     	
     	
     	ArrayList<WebElement> wePosts = (ArrayList<WebElement>) driver.findElements(By.xpath("//option[text()='"+name+"']"));
 		
 		return !wePosts.isEmpty();
 	
     }
  
 
  
    
    public boolean isPostInListContainingTitleText() {
	 
	 try {
		Thread.sleep(2000);
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
		
		ArrayList<WebElement> wePosts = (ArrayList<WebElement>) driver.findElements(By.xpath("//td[contains(text(),'Title')]"));
		
	
		return !wePosts.isEmpty();
	}
    
    public String updateMessage() {
    	driverWait.until(ExpectedConditions.visibilityOf(weUpdateMessage));
    	return weUpdateMessage.getText();
    }
    

}
