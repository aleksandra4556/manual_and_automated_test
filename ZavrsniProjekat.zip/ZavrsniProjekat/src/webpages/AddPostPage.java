package webpages;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class AddPostPage {

	private WebDriver driver;
	private WebDriverWait driverWait;
	private static final String PAGE_URl = "https://testblog.kurs-qa.cubes.edu.rs/admin/posts/add";
	
	//WebElements
	@FindBy(name="post_category_id")
	private WebElement weCategory;
	
	@FindBy(name="title")
	private WebElement weTitle;
	
	@FindBy(name="description")
	private WebElement weDescription;
	
	
	@FindBy(id="set-as-important")
	private WebElement weImportantYes;
	
	//@FindBy(name="photo")
	//private WebElement wePhoto;
	
	@FindBy(id="cke_1_contents")
	private WebElement weContent;
	
	@FindBy(xpath="//button[text()='Save']")
	private WebElement weSaveButton;
	
	@FindBy(xpath="//a[text()='Cancel']")
	private WebElement weCancelButton;
	
	@FindBy(xpath="//a[@href='https://testblog.kurs-qa.cubes.edu.rs/admin']")
	private WebElement weHome;
	
	@FindBy(xpath="//a[text()='Post']")
	private WebElement wePost;
	
	@FindBy(xpath="//i[@class='far fa-user']")
	private WebElement weProfile;
	
	@FindBy(xpath="//a[@href='https://testblog.kurs-qa.cubes.edu.rs/logout']")
	private WebElement weLogoutButton;
	
	@FindBy(xpath="//a[@class='nav-link']")
	private WebElement weNavigation;
	
	public AddPostPage(WebDriver driver, WebDriverWait driverWait) {
		
		this.driver=driver;
		this.driverWait=driverWait;
		this.driver.get(PAGE_URl);
		this.driver.manage().window().maximize();
		PageFactory.initElements(driver,this);
	}
	
	public void openPage() {
		driver.get(PAGE_URl);
	}
	
	public void chooseCategory(String category) {
		
		Select select = new Select(weCategory);
		
		select.selectByVisibleText(category);
	}
	
	public void title(String title) {
		
		weTitle.clear();
		weTitle.sendKeys(title);
	}
	
	public void description(String description) {
		
		weDescription.clear();
		weDescription.sendKeys(description);
	}
	
	
	public void importantYes() {

		JavascriptExecutor js = (JavascriptExecutor)driver;
		js.executeScript("arguments[0].click()", weImportantYes);
	}
	
	public void tags(String tags) {
		
		WebElement weTags = driver.findElement(By.xpath("//label[@class='form-check-label' and text()='"+tags+"' ]"));
		
		JavascriptExecutor js = (JavascriptExecutor)driver;
		js.executeScript("arguments[0].click()", weTags);
		
	}
	
	
	public void addPhoto() {
		
		WebElement we = driver.findElement(By.name("photo"));
		
		we.sendKeys("I:\\Users\\jovan\\Desktop\\projekat\\maslačak.jpg");
		
	}
	
	public void content(String content) {
		
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", weContent);
		
		driver.switchTo().frame(0);
		
		WebElement we = driver.findElement(By.xpath("//body[@class='cke_editable cke_editable_themed cke_contents_ltr cke_show_borders']"));
		
		we.clear();
		we.sendKeys(content);
		
		driver.switchTo().defaultContent();
		
	}
	
	public void savePost() {
		
		
		
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", weSaveButton);
		
        try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
     
        JavascriptExecutor js = (JavascriptExecutor)driver;
		js.executeScript("arguments[0].click()", weSaveButton);
		
	}
	
	public void cancelPost() {
		
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", weCancelButton);
		
        try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        
        JavascriptExecutor js = (JavascriptExecutor)driver;
		js.executeScript("arguments[0].click()", weCancelButton);
	}
	
	public void home() {
		
		weHome.click();
	}
	
	public void post() {
		
		
		wePost.click();
	}
	
	public void logout() {
		
		weProfile.click();
		weLogoutButton.click();
	}
	
	public void navigaton() {
		
		weNavigation.click();
	}
	
	public String titleErrorMessage() {
    	WebElement we = driver.findElement(By.id("title-error"));
    	return we.getText();
    }
    
    public String descriptionErrorMessage() {
    	WebElement we = driver.findElement(By.id("description-error"));
    	return we.getText();
    }
    
    public String tagsErrorMessage() {
    	WebElement we = driver.findElement(By.id("tag_id[]-error"));
    	return we.getText();
    }
    
    public String contentErrorMesage() {
    	WebElement we = driver.findElement(By.xpath("//div[@class='invalid-feedback']"));
    	return we.getText();
    }
}
