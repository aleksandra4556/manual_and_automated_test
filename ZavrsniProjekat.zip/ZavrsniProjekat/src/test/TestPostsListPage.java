package test;

import static org.junit.Assert.*;

import java.time.Duration;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.WebDriverWait;

import webpages.AddPostPage;
import webpages.LoginPage;
import webpages.PostsListPage;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TestPostsListPage {
	

	private static ChromeDriver driver;
	private static LoginPage loginPage;
	private static PostsListPage postsListPage;
	private static AddPostPage addPostPage;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		System.setProperty("Webdriver.chrome.driver", "I:\\Users\\jovan\\Desktop/webdriver/chromdriver");
		ChromeOptions options = new ChromeOptions();
		options.addArguments("--remote-allow-origins=*");
		driver = new ChromeDriver(options);
	    WebDriverWait driverWait = new WebDriverWait(driver, Duration.ofMillis(10000));
	    
	    loginPage = new LoginPage(driver);
	    addPostPage = new AddPostPage(driver, driverWait);
	    postsListPage = new PostsListPage(driver,driverWait);
	    loginPage.loginSuccess();
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
		postsListPage.openPage();
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void tc03NoneExistingTitle() {
		
	   postsListPage.title("Avion");
		
	   assertEquals(postsListPage.noMatchingRecordsMessage(), "No matching records found");
	}
	
	@Test
	public void tc04ExistingTitleText() {
		
		postsListPage.title("Title");
		
		assertEquals(postsListPage.isPostInListContainingTitleText(), true);
	}
	
	@Test
	public void tc05ExistingTitle() {
		
		postsListPage.title("70s music rare soul al green");
		
		assertEquals(postsListPage.isPostInList("70s music rare soul al green"),true);
	
		
	}
	
	@Test
	public void tc06ExistingTitleAndCorrectAuthor() {
		
		postsListPage.title("70s music rare soul al green");
		postsListPage.author("Polaznik Kursa");
		
		assertEquals(postsListPage.isPostInList("70s music rare soul al green"), true);
		assertEquals(postsListPage.isPostInListAuthor("Polaznik Kursa"), true);
		
		
		
	}
	
	@Test
	public void tc07ExistingTitleAndFalseAuthor() {
		
		postsListPage.title("70s music rare soul al green");
		postsListPage.author("Vladan Dzulovic");
		
		 assertEquals(postsListPage.noMatchingRecordsMessage(), "No matching records found");
		
	}
	
	@Test
    public void tc08ExistingTitleAndFalseAuthor() {
		
		postsListPage.title("70s music rare soul al green");
		postsListPage.author("Marko Dragonjic");
		
		 assertEquals(postsListPage.noMatchingRecordsMessage(), "No matching records found");
		
		
	}
	
	@Test
    public void tc09ExistingTitleAndFalseAuthor() {
		
		postsListPage.title("70s music rare soul al green");
		postsListPage.author("Resset Pass User - NE BRISATI");
		
		 assertEquals(postsListPage.noMatchingRecordsMessage(), "No matching records found");
		
	}
	
	@Test
	public void tc10ExistingTitleAndCorrectCategory() {
		
		postsListPage.title("70s music rare soul al green");
		postsListPage.category("Clarkstad");
		
		assertEquals(postsListPage.isPostInList("70s music rare soul al green"), true);
		assertEquals(postsListPage.isPostInListCategory("Clarkstad"), true);
	}
	
	@Test
	public void tc11ExistingTitleAndFalseCategory() {
		
		postsListPage.title("70s music rare soul al green");
		postsListPage.category("Vladimir QA");
		
		 assertEquals(postsListPage.noMatchingRecordsMessage(), "No matching records found");
	}
	
	@Test
	public void tc12ExistingTitleAndFalseCategory() {
		
		postsListPage.title("70s music rare soul al green");
		postsListPage.category("Ivona");
		
		 assertEquals(postsListPage.noMatchingRecordsMessage(), "No matching records found");
	}
	
	@Test
	public void tc13ExistingTitleAndFalseCategory() {
		
		postsListPage.title("70s music rare soul al green");
		postsListPage.category("VukTestCat");
		
		 assertEquals(postsListPage.noMatchingRecordsMessage(), "No matching records found");
	}
	
	@Test
	public void tc14ExistingTitleAndFalseCategory() {
		
		postsListPage.title("70s music rare soul al green");
		postsListPage.category("Jelena");
		
		 assertEquals(postsListPage.noMatchingRecordsMessage(), "No matching records found");
	}
	
	@Test
	public void tc15ExistingTitleAndFalseCategory() {
		
		postsListPage.title("70s music rare soul al green");
		postsListPage.category("Walt Disney");
		
		 assertEquals(postsListPage.noMatchingRecordsMessage(), "No matching records found");
		 assertEquals(postsListPage.isPostInListCategory("Walt Disney"), true);
	}
	
	@Test
	public void tc16ExistingTitleAndImportantAll() {
		postsListPage.title("70s music rare soul al green");
		postsListPage.important("-- All --");
		
		assertEquals(postsListPage.isPostInList("70s music rare soul al green"), true);
		assertEquals(postsListPage.isPostInListImportant("-- All --"), true);
	}
	
	@Test
	public void tc17ExistingTitleAndImportantYes() {
		postsListPage.title("70s music rare soul al green");
		postsListPage.important("yes");
		
		assertEquals(postsListPage.noMatchingRecordsMessage(), "No matching records found");
		
	}
	
	@Test
	public void tc18ExistingTitleAndImportantNo() {
		postsListPage.title("70s music rare soul al green");
		postsListPage.important("no");
	
		assertEquals(postsListPage.isPostInList("70s music rare soul al green"), true);
		assertEquals(postsListPage.isPostInListImportant("yes"), true);
	}
	
	@Test
	public void tc19ExsitingTitleAndStatusAll() {
		postsListPage.title("70s music rare soul al green");
		postsListPage.status("-- All --");
		
		assertEquals(postsListPage.isPostInList("70s music rare soul al green"), true);
		assertEquals(postsListPage.isPostInListImportant("-- All --"), true);
	}
	
	@Test
	public void tc20ExsitingTitleAndStatusEnabled() {
		postsListPage.title("70s music rare soul al green");
		postsListPage.status("enabled");
		
		assertEquals(postsListPage.isPostInList("70s music rare soul al green"), true);
		assertEquals(postsListPage.isPostInListStatus("enabled"), true);
	}
	
	@Test
	public void tc21ExsitingTitleAndStatusDisabled() {
		postsListPage.title("70s music rare soul al green");
		postsListPage.status("disabled");
		
		assertEquals(postsListPage.noMatchingRecordsMessage(), "No matching records found");
	}
	
	@Test
	public void tc22ExistingTitleAndWithTag() {
		postsListPage.title("70s music rare soul al green");
		postsListPage.withTag("NEW Tag782");
		
		assertEquals(postsListPage.noMatchingRecordsMessage(), "No matching records found");
	}
	
	@Test
	public void tc23ExistingTitleAndWithTag() {
		postsListPage.title("70s music rare soul al green");
		postsListPage.withTag("eos");
		
		assertEquals(postsListPage.noMatchingRecordsMessage(), "No matching records found");
	}
	
	@Test
	public void tc24ExistingTitleAndWithTag() {
		postsListPage.title("70s music rare soul al green");
		postsListPage.withTag("Tag 1983");
		
		assertEquals(postsListPage.noMatchingRecordsMessage(), "No matching records found");
	}
	
	@Test
	public void tc25ExistingTitleAndWithTag() {
		postsListPage.title("70s music rare soul al green");
		postsListPage.withTag("Vuk");
		postsListPage.withTag("sit");
		
		assertEquals(postsListPage.isPostInList("70s music rare soul al green"), true);
		assertEquals(postsListPage.isPostInListWithTag("Vuk"), true);
		assertEquals(postsListPage.isPostInListWithTag("sit"), true);
	}
	
	@Test
	public void tc26NoneExistingTitleAndExsistingAuthor() {
		postsListPage.title("Avion");
		postsListPage.author("Polaznik Kursa");
		
		assertEquals(postsListPage.noMatchingRecordsMessage(), "No matching records found");
	}
	
	@Test
	public void tc27NoneExistingTitleAndExsistingAuthor() {
		postsListPage.title("Avion");
		postsListPage.author("Vladan Dzulovic");
		
		assertEquals(postsListPage.noMatchingRecordsMessage(), "No matching records found");
	}
	
	@Test
	public void tc28NoneExistingTitleAndExsistingCategory() {
		postsListPage.title("Avion");
		postsListPage.category("Clarkstad");
		
		assertEquals(postsListPage.noMatchingRecordsMessage(), "No matching records found");
	}
	
	@Test
	public void tc29NoneExistingTitleAndExsistingCategory() {
		postsListPage.title("Avion");
		postsListPage.category("Ivona");
		
		assertEquals(postsListPage.noMatchingRecordsMessage(), "No matching records found");
	}
	
	@Test
	public void tc30NoneExistingTitleAndExsistingCategory() {
		postsListPage.title("Avion");
		postsListPage.category("Vladimir QA");
		
		assertEquals(postsListPage.noMatchingRecordsMessage(), "No matching records found");
	}
	
	@Test
	public void tc31NoneExistingTitleAndImportantAll() {
		postsListPage.title("Avion");
		postsListPage.important("-- All --");
		
		assertEquals(postsListPage.noMatchingRecordsMessage(), "No matching records found");
	}
	
	@Test
	public void tc32NoneExistingTitleAndImportantYes() {
		postsListPage.title("Avion");
		postsListPage.important("yes");
		
		assertEquals(postsListPage.noMatchingRecordsMessage(), "No matching records found");
	}
	
	@Test
	public void tc33NoneExistingTitleAndImportantNo() {
		postsListPage.title("Avion");
		postsListPage.important("no");
		
		assertEquals(postsListPage.noMatchingRecordsMessage(), "No matching records found");
	}
	
	@Test
	public void tc34NoneExistingTitleAndStatusAll() {
		postsListPage.title("Avion");
		postsListPage.status("-- All --");
		
		assertEquals(postsListPage.noMatchingRecordsMessage(), "No matching records found");
	}
	
	@Test
	public void tc35NoneExistingTitleAndStatusEnabled() {
		postsListPage.title("Avion");
		postsListPage.status("enabled");
		
		assertEquals(postsListPage.noMatchingRecordsMessage(), "No matching records found");
	}
	
	@Test
	public void tc36NoneExistingTitleAndStatusDisabled() {
		postsListPage.title("Avion");
		postsListPage.status("disabled");
		
		assertEquals(postsListPage.noMatchingRecordsMessage(), "No matching records found");
	}
	
	@Test
	public void tc37NoneExistingTitleAndWithTag() {
		postsListPage.title("Avion");
		postsListPage.withTag("eos");
		
		assertEquals(postsListPage.noMatchingRecordsMessage(), "No matching records found");
	}
	
	@Test
	public void tc38NoneExistingTitleAndWithTag() {
		postsListPage.title("Avion");
		postsListPage.withTag("Vuk");
		
		assertEquals(postsListPage.noMatchingRecordsMessage(), "No matching records found");
	}
	
	@Test
	public void tc39NoneExistingTitleAndWithTag() {
		postsListPage.title("Avion");
		postsListPage.withTag("sit");
		
		assertEquals(postsListPage.noMatchingRecordsMessage(), "No matching records found");
	}
	
	@Test
	public void tc40ExistingTitleTextAndAuthor() {
		postsListPage.title("Title");
		postsListPage.author("Polaznik Kursa");
		
		assertEquals(postsListPage.isPostInListContainingTitleText(), true);
		assertEquals(postsListPage.isPostInListAuthor("Polaznik Kursa"), true);
	}
	
	@Test
	public void tc41ExistingTitleTextAndAuthor() {
		postsListPage.title("Title");
		postsListPage.author("Vladan Dzulovic");
		
		assertEquals(postsListPage.noMatchingRecordsMessage(), "No matching records found");
	}
	
	@Test
	public void tc42ExistingTitleTextAndCategory() {
		postsListPage.title("Title");
		postsListPage.category("Clarkstad");
		
		assertEquals(postsListPage.isPostInListContainingTitleText(), true);
		assertEquals(postsListPage.isPostInListCategory("Clarkstad"), true);
	}
	
	@Test
	public void tc43ExistingTitleTextAndCategory() {
		postsListPage.title("Title");
		postsListPage.category("Vladimir QA");
		
		assertEquals(postsListPage.noMatchingRecordsMessage(), "No matching records found");
	}
	
	@Test
	public void tc44ExistingTitleTextAndCategory() {
		postsListPage.title("Title");
		postsListPage.category("Irina");
		
		assertEquals(postsListPage.noMatchingRecordsMessage(), "No matching records found");
	}
	
	@Test
	public void tc45ExistingTitleTextAndImportantAll() {
		postsListPage.title("Title");
		postsListPage.important("-- All --");
		
		assertEquals(postsListPage.isPostInListContainingTitleText(), true);
		assertEquals(postsListPage.isPostInListImportant("-- All --"), true);
	}
	
	@Test
	public void tc46ExistingTitleTextAndImportantyes() {
		postsListPage.title("Title");
		postsListPage.important("yes");
		
		assertEquals(postsListPage.noMatchingRecordsMessage(), "No matching records found");
	}
	
	@Test
	public void tc47ExistingTitleTextAndImportantNo() {
		postsListPage.title("Title");
		postsListPage.important("no");
		
		assertEquals(postsListPage.isPostInListContainingTitleText(), true);
		assertEquals(postsListPage.isPostInListImportant("no"), true);
	}
	
	@Test
	public void tc48ExistingTitleTextAndStatusAll() {
		postsListPage.title("Title");
		postsListPage.status("-- All --");
		
		assertEquals(postsListPage.isPostInListContainingTitleText(), true);
		assertEquals(postsListPage.isPostInListStatus("-- All --"), true);
	}
	
	@Test
	public void tc49ExistingTitleTextAndStatusEnabled() {
		postsListPage.title("Title");
		postsListPage.status("enabled");
		
		assertEquals(postsListPage.isPostInListContainingTitleText(), true);
		assertEquals(postsListPage.isPostInListStatus("enabled"), true);
	}
	
	@Test
	public void tc50ExistingTitleTextAndStatusDisbaled() {
		postsListPage.title("Title");
		postsListPage.status("disabled");
		
		assertEquals(postsListPage.isPostInListContainingTitleText(), true);
		assertEquals(postsListPage.isPostInListStatus("disabled"), true);
	}
	
	@Test
	public void tc51ExistingTitleTextAndWithTag() {
		postsListPage.title("Title");
		postsListPage.withTag("eos");
		
		assertEquals(postsListPage.noMatchingRecordsMessage(), "No matching records found");
	}
	
	@Test
	public void tc52ExistingTitleTextAndWithTag() {
		postsListPage.title("Title");
		postsListPage.withTag("sit");
		
		assertEquals(postsListPage.noMatchingRecordsMessage(), "No matching records found");
	}
	
	@Test
	public void tc53ExistingTitleTextAndWithTag() {
		postsListPage.title("Title");
		postsListPage.withTag("Vuk");
		
		assertEquals(postsListPage.isPostInListContainingTitleText(), true);
		assertEquals(postsListPage.isPostInListWithTag("Vuk"), true);
	}
	
	@Test
	public void tc54SelectAuthor() {
		postsListPage.author("Polaznik Kursa");
		
		assertEquals(postsListPage.isPostInList("Polaznik Kursa"), true);
	}
	
	@Test
	public void tc55SelectAuthor() {
		postsListPage.author("Vladan Dzulovic");
		
		assertEquals(postsListPage.noMatchingRecordsMessage(), "No matching records found");
	}
	
	@Test
	public void tc56SelectAuthor() {
		postsListPage.author("Marko Dragonjic");
		
		assertEquals(postsListPage.noMatchingRecordsMessage(), "No matching records found");
	}
	
	@Test
	public void tc57SelectAuthorAndCategory() {
		postsListPage.author("Polaznik Kursa");
		postsListPage.category("Clarkstad");
		
		assertEquals(postsListPage.isPostInList("Polaznik Kursa"), true);
		assertEquals(postsListPage.isPostInListCategory("Clarkstad"), true);
	}
	
	@Test
	public void tc58SelectAuthorAndCategory() {
		postsListPage.author("Polaznik Kursa");
		postsListPage.category("Vladimir QA");
		
		assertEquals(postsListPage.isPostInList("Polaznik Kursa"), true);
		assertEquals(postsListPage.isPostInListCategory("Vladimir QA"), true);
		
	}
	
	@Test
	public void tc59SelectAuthorAndCategory() {
		postsListPage.author("Polaznik Kursa");
		postsListPage.category("Ivona");
		
		assertEquals(postsListPage.isPostInList("Polaznik Kursa"), true);
		assertEquals(postsListPage.isPostInListCategory("Ivona"), true);
	}
	
	@Test
	public void tc60SelectAuthorAndCategory() {
		postsListPage.author("Vladan Dzulovic");
		postsListPage.category("Clarkstad");
		
		assertEquals(postsListPage.noMatchingRecordsMessage(), "No matching records found");
	}
	
	@Test
	public void tc61SelectAuthorAndCategory() {
		postsListPage.author("Vladan Dzulovic");
		postsListPage.category("Vladimir QA");
		
		assertEquals(postsListPage.noMatchingRecordsMessage(), "No matching records found");
	}
	
	@Test
	public void tc62SelectAuthorAndCategory() {
		postsListPage.author("Vladan Dzulovic");
		postsListPage.category("Ivona");
		
		assertEquals(postsListPage.noMatchingRecordsMessage(), "No matching records found");
	}
	
	@Test
	public void tc63SelectAuthorAndCategory() {
		postsListPage.author("Marko Dragonjic");
		postsListPage.category("Clarkstad");
		
		assertEquals(postsListPage.noMatchingRecordsMessage(), "No matching records found");
	}
	
	@Test
	public void tc64SelectAuthorAndCategory() {
		postsListPage.author("Marko Dragonjic");
		postsListPage.category("Vladimir QA");
		
		assertEquals(postsListPage.noMatchingRecordsMessage(), "No matching records found");
	}
	
	@Test
	public void tc65SelectAuthorAndCategory() {
		postsListPage.author("Marko Dragonjic");
		postsListPage.category("Ivona");
		
		assertEquals(postsListPage.noMatchingRecordsMessage(), "No matching records found");
	}
	
	@Test
	public void tc66SelectAuthorAndImportantAll() {
		postsListPage.author("Polaznik Kursa");
		postsListPage.important("-- All --");
		
		assertEquals(postsListPage.isPostInList("Polaznik Kursa"), true);
		assertEquals(postsListPage.isPostInListImportant("-- All --"), true);
	}
	
	@Test
	public void tc67SelectAuthorAndImportantAll() {
		postsListPage.author("Polaznik Kursa");
		postsListPage.important("yes");
		
		assertEquals(postsListPage.isPostInList("Polaznik Kursa"), true);
		assertEquals(postsListPage.isPostInListImportant("yes"), true);
	}
	
	@Test
	public void tc68SelectAuthorAndImportantNo() {
		postsListPage.author("Polaznik Kursa");
		postsListPage.important("no");
		
		assertEquals(postsListPage.isPostInList("Polaznik Kursa"), true);
		assertEquals(postsListPage.isPostInListImportant("no"), true);
	}
	
	@Test
	public void tc69SelectAuthorAndImportantAll() {
		postsListPage.author("Vladan Dzulovic");
		postsListPage.important("-- All --");
		
		assertEquals(postsListPage.noMatchingRecordsMessage(), "No matching records found");
	}
	
	@Test
	public void tc70SelectAuthorAndImportantYes() {
		postsListPage.author("Vladan Dzulovic");
		postsListPage.important("yes");
		
		assertEquals(postsListPage.noMatchingRecordsMessage(), "No matching records found");
	}
	
	@Test
	public void tc71SelectAuthorAndImportantNo() {
		postsListPage.author("Vladan Dzulovic");
		postsListPage.important("no");
		
		assertEquals(postsListPage.noMatchingRecordsMessage(), "No matching records found");
	}
	
	@Test
	public void tc72SelectAuthorAndImportantAll() {
		postsListPage.author("Marko Dragonjic");
		postsListPage.important("-- All --");
		
		assertEquals(postsListPage.noMatchingRecordsMessage(), "No matching records found");
	}
	
	@Test
	public void tc73SelectAuthorAndImportantYes() {
		postsListPage.author("Marko Dragonjic");
		postsListPage.important("yes");
		
		assertEquals(postsListPage.noMatchingRecordsMessage(), "No matching records found");
	}
	
	@Test
	public void tc74SelectAuthorAndImportantNo() {
		postsListPage.author("Marko Dragonjic");
		postsListPage.important("no");
		
		assertEquals(postsListPage.noMatchingRecordsMessage(), "No matching records found");
	}
	
	@Test
	public void tc75SelectAuthorAndStatusAll() {
		postsListPage.author("Polaznik Kursa");
		postsListPage.status("-- All --");
		
		assertEquals(postsListPage.isPostInList("Polaznik Kursa"), true);
		assertEquals(postsListPage.isPostInListStatus("-- All --"), true);
	}
	
	@Test
	public void tc76SelectAuthorAndStatusEnabled() {
		postsListPage.author("Polaznik Kursa");
		postsListPage.status("enabled");
		
		assertEquals(postsListPage.isPostInList("Polaznik Kursa"), true);
		assertEquals(postsListPage.isPostInListStatus("enabled"), true);
	}
	
	@Test
	public void tc77SelectAuthorAndStatusDisabled() {
		postsListPage.author("Polaznik Kursa");
		postsListPage.status("disabled");
		
		assertEquals(postsListPage.isPostInList("Polaznik Kursa"), true);
		assertEquals(postsListPage.isPostInListStatus("disabled"), true);
	}
	
	@Test
	public void tc78SelectAuthorAndStatusAll() {
		postsListPage.author("Vladan Dzulovic");
		postsListPage.status("-- All --");
		
		assertEquals(postsListPage.noMatchingRecordsMessage(), "No matching records found");
	}
	
	@Test
	public void tc79SelectAuthorAndStatusEnabled() {
		postsListPage.author("Vladan Dzulovic");
		postsListPage.status("enabled");
		
		assertEquals(postsListPage.noMatchingRecordsMessage(), "No matching records found");
	}
	
	@Test
	public void tc80SelectAuthorAndStatusDisabled() {
		postsListPage.author("Vladan Dzulovic");
		postsListPage.status("disabled");
		
		assertEquals(postsListPage.noMatchingRecordsMessage(), "No matching records found");
	}
	
	@Test
	public void tc81SelectAuthorAndStatusAll() {
		postsListPage.author("Marko Dragonjic");
		postsListPage.status("-- All --");
		
		assertEquals(postsListPage.noMatchingRecordsMessage(), "No matching records found");
	}
	
	@Test
	public void tc82SelectAuthorAndStatusEnabled() {
		postsListPage.author("Marko Dragonjic");
		postsListPage.status("enabled");
		
		assertEquals(postsListPage.noMatchingRecordsMessage(), "No matching records found");
	}
	
	@Test
	public void tc83SelectAuthorAndStatusDisabled() {
		postsListPage.author("Marko Dragonjic");
		postsListPage.status("disabled");
		
		assertEquals(postsListPage.noMatchingRecordsMessage(), "No matching records found");
	}
	
	@Test
	public void tc84SelectAuthorAndWithTag() {
		postsListPage.author("Polaznik Kursa");
		postsListPage.withTag("eos");
		
		assertEquals(postsListPage.isPostInList("Polaznik Kursa"), true);
		assertEquals(postsListPage.isPostInListWithTag("eos"), true);
	}
	
	@Test
	public void tc85SelectAuthorAndWithTag() {
		postsListPage.author("Polaznik Kursa");
		postsListPage.withTag("NEW Tag782");
		
		assertEquals(postsListPage.noMatchingRecordsMessage(), "No matching records found");
	}
	
	@Test
	public void tc86SelectAuthorAndWithTag() {
		postsListPage.author("Polaznik Kursa");
		postsListPage.withTag("sit");
		
		assertEquals(postsListPage.isPostInList("Polaznik Kursa"), true);
		assertEquals(postsListPage.isPostInListWithTag("sit"), true);
	}
	
	@Test
	public void tc87SelectAuthorAndWithTag() {
		postsListPage.author("Vladan Dzulovic");
		postsListPage.withTag("eos");
		
		assertEquals(postsListPage.noMatchingRecordsMessage(), "No matching records found");
	}
	
	@Test
	public void tc88SelectAuthorAndWithTag() {
		postsListPage.author("Vladan Dzulovic");
		postsListPage.withTag("NEW Tag782");
		
		assertEquals(postsListPage.noMatchingRecordsMessage(), "No matching records found");
	}
	
	@Test
	public void tc89SelectAuthorAndWithTag() {
		postsListPage.author("Vladan Dzulovic");
		postsListPage.withTag("sit");
		
		assertEquals(postsListPage.noMatchingRecordsMessage(), "No matching records found");
	}
	
	@Test
	public void tc90SelectAuthorAndWithTag() {
		postsListPage.author("Marko Dragonjic");
		postsListPage.withTag("eos");
		
		assertEquals(postsListPage.noMatchingRecordsMessage(), "No matching records found");
	}
	
	@Test
	public void tc91SelectAuthorAndWithTag() {
		postsListPage.author("Marko Dragonjic");
		postsListPage.withTag("NEW Tag782");
		
		assertEquals(postsListPage.noMatchingRecordsMessage(), "No matching records found");
	}
	
	@Test
	public void tc92SelectAuthorAndWithTag() {
		postsListPage.author("Marko Dragonjic");
		postsListPage.withTag("sit");
		
		assertEquals(postsListPage.noMatchingRecordsMessage(), "No matching records found");
	}
	
	@Test
	public void tc93SelectCategory() {
		postsListPage.category("Clarkstad");
		
		assertEquals(postsListPage.isPostInListCategory("Clarkstad"), true);
	}
	
	@Test
	public void tc94SelectCategory() {
		postsListPage.category("Vladimir QA");
		
		assertEquals(postsListPage.isPostInListCategory("Vladimir QA"), true);
	}
	
	@Test
	public void tc95SelectCategory() {
		postsListPage.category("Ivona");
		
		assertEquals(postsListPage.isPostInListCategory("Ivona"), true);
	}
	
	@Test
	public void tc96SelectCategoryAndImportantAll() {
		postsListPage.category("Clarkstad");
		postsListPage.important("-- All --");
		
		assertEquals(postsListPage.isPostInListCategory("Clarkstad"), true);
		assertEquals(postsListPage.isPostInListImportant("-- All --"), true);
	}
	
	@Test
	public void tc97SelectCategoryAndImportantYes() {
		postsListPage.category("Clarkstad");
		postsListPage.important("yes");
		
		assertEquals(postsListPage.isPostInListCategory("Clarkstad"), true);
		assertEquals(postsListPage.isPostInListImportant("yes"), true);
	}
	
	@Test
	public void tc98SelectCategoryAndImportantNo() {
		postsListPage.category("Clarkstad");
		postsListPage.important("no");
		
		assertEquals(postsListPage.isPostInListCategory("Clarkstad"), true);
		assertEquals(postsListPage.isPostInListImportant("no"), true);
	}
	
	@Test
	public void tc99SelectCategoryAndImportantAll() {
		postsListPage.category("Vladimir QA");
		postsListPage.important("-- All --");
		
		assertEquals(postsListPage.isPostInListCategory("Vladimir QA"), true);
		assertEquals(postsListPage.isPostInListImportant("-- All --"), true);
	}
	
	@Test
	public void tc100SelectCategoryAndImportantYes() {
		postsListPage.category("Vladimir QA");
		postsListPage.important("yes");
		
		assertEquals(postsListPage.isPostInListCategory("Vladimir QA"), true);
		assertEquals(postsListPage.isPostInListImportant("yes"), true);
		
	}
	
	@Test
	public void tc101SelectCategoryAndImportantNo() {
		postsListPage.category("Vladimir QA");
		postsListPage.important("no");
		
		assertEquals(postsListPage.noMatchingRecordsMessage(), "No matching records found");
	}
	
	@Test
	public void tc102SelectCategoryAndImportantAll() {
		postsListPage.category("Ivona");
		postsListPage.important("-- All --");
		
		assertEquals(postsListPage.isPostInListCategory("Ivona"), true);
		assertEquals(postsListPage.isPostInListImportant("-- All --"), true);
	}
	
	@Test
	public void tc103SelectCategoryAndImportantYes() {
		postsListPage.category("Ivona");
		postsListPage.important("yes");
		
		assertEquals(postsListPage.isPostInListCategory("Ivona"), true);
		assertEquals(postsListPage.isPostInListImportant("yes"), true);
	}
	
	@Test
	public void tc104SelectCategoryAndImportantNo() {
		postsListPage.category("Ivona");
		postsListPage.important("no");
		
		assertEquals(postsListPage.isPostInListCategory("Ivona"), true);
		assertEquals(postsListPage.isPostInListImportant("no"), true);
	}
	
	@Test
	public void tc105SelectCategoryAndStatusAll() {
		postsListPage.category("Clarkstad");
		postsListPage.status("-- All --");
		
		assertEquals(postsListPage.isPostInListCategory("Clarkstad"), true);
		assertEquals(postsListPage.isPostInListStatus("-- All --"), true);
	}
	
	@Test
	public void tc106SelectCategoryAndStatusEnabled() {
		postsListPage.category("Clarkstad");
		postsListPage.status("enabled");
		
		assertEquals(postsListPage.isPostInListCategory("Clarkstad"), true);
		assertEquals(postsListPage.isPostInListStatus("enabled"), true);
	}
	
	@Test
	public void tc107SelectCategoryAndStatusDisabled() {
		postsListPage.category("Clarkstad");
		postsListPage.status("disabled");
		
		assertEquals(postsListPage.isPostInListCategory("Clarkstad"), true);
		assertEquals(postsListPage.isPostInListStatus("disabled"), true);
	}
	
	@Test
	public void tc108SelectCategoryAndStatusAll() {
		postsListPage.category("Vladimir QA");
		postsListPage.status("-- All --");
		
		assertEquals(postsListPage.isPostInListCategory("Vladimir QA"), true);
		assertEquals(postsListPage.isPostInListStatus("-- All --"), true);
	}
	
	@Test
	public void tc109SelectCategoryAndStatusEnabled() {
		postsListPage.category("Vladimir QA");
		postsListPage.status("enabled");
		
		assertEquals(postsListPage.isPostInListCategory("Vladimir QA"), true);
		assertEquals(postsListPage.isPostInListStatus("enabled"), true);
	}
	

	@Test
	public void tc110SelectCategoryAndStatusDisabled() {
		postsListPage.category("Vladimir QA");
		postsListPage.status("disabled");
		
		assertEquals(postsListPage.noMatchingRecordsMessage(), "No matching records found");
	}
	
	@Test
	public void tc111SelectCategoryAndStatusAll() {
		postsListPage.category("Ivona");
		postsListPage.status("-- All --");
		
		assertEquals(postsListPage.isPostInListCategory("Ivona"), true);
		assertEquals(postsListPage.isPostInListStatus("-- All --"), true);
	}
	
	@Test
	public void tc112SelectCategoryAndStatusEnabled() {
		postsListPage.category("Ivona");
		postsListPage.status("enabled");
		
		assertEquals(postsListPage.isPostInListCategory("Ivona"), true);
		assertEquals(postsListPage.isPostInListStatus("enabled"), true);
	}
	
	@Test
	public void tc113SelectCategoryAndStatusDisabled() {
		postsListPage.category("Ivona");
		postsListPage.status("disabled");
		
		assertEquals(postsListPage.isPostInListCategory("Ivona"), true);
		assertEquals(postsListPage.isPostInListStatus("disabled"), true);
	}
	
	@Test
	public void tc114SelectCategoryAndWithTag() {
		postsListPage.category("Clarkstad");
		postsListPage.withTag("eos");
		
		assertEquals(postsListPage.noMatchingRecordsMessage(), "No matching records found");
	}
	
	@Test
	public void tc115SelectCategoryAndWithTag() {
		postsListPage.category("Clarkstad");
		postsListPage.withTag("NEW Tag782");
		
		assertEquals(postsListPage.noMatchingRecordsMessage(), "No matching records found");
	}
	
	@Test
	public void tc116SelectCategoryAndWithTag() {
		postsListPage.category("Clarkstad");
		postsListPage.withTag("Vuk");
		
		assertEquals(postsListPage.isPostInListCategory("Clarkstad"), true);
		assertEquals(postsListPage.isPostInListWithTag("Vuk"), true);
	}
	
	@Test
	public void tc117SelectCategoryAndWithTag() {
		postsListPage.category("Vladimir QA");
		postsListPage.withTag("eos");
		
		assertEquals(postsListPage.noMatchingRecordsMessage(), "No matching records found");
	}
	
	@Test
	public void tc118SelectCategoryAndWithTag() {
		postsListPage.category("Vladimir QA");
		postsListPage.withTag("sit");
		
		assertEquals(postsListPage.noMatchingRecordsMessage(), "No matching records found");
	}
	
	@Test
	public void tc119SelectCategoryAndWithTag() {
		postsListPage.category("Vladimir QA");
		postsListPage.withTag("Simba");
		
		assertEquals(postsListPage.noMatchingRecordsMessage(), "No matching records found");
	}
	@Test
	public void tc120SelectCategoryAndWithTag() {
		postsListPage.category("Ivona");
		postsListPage.withTag("eos");
		
		assertEquals(postsListPage.noMatchingRecordsMessage(), "No matching records found");
	}

	@Test
	public void tc121SelectCategoryAndWithTag() {
		postsListPage.category("Ivona");
		postsListPage.withTag("sit");
		
		assertEquals(postsListPage.noMatchingRecordsMessage(), "No matching records found");
	}
	
	@Test
	public void tc122SelectCategoryAndWithTag() {
		postsListPage.category("Ivona");
		postsListPage.withTag("Simba");
		
		assertEquals(postsListPage.noMatchingRecordsMessage(), "No matching records found");
	}
	
	@Test
	public void tc123SelectImportantAll() {
		postsListPage.important("-- All --");
		
		assertEquals(postsListPage.isPostInListImportant("-- All --"), true);
	}
	
	@Test
	public void tc124SelectImportantYes() {
		postsListPage.important("yes");
		
		assertEquals(postsListPage.isPostInListImportant("yes"), true);
	}
	
	@Test
	public void tc125SelectImportantNo() {
		postsListPage.important("no");
		
		assertEquals(postsListPage.isPostInListImportant("no"), true);
	}
	
	@Test
	public void tc126SelectImportantAllAndStatusAll() {
		postsListPage.important("-- All --");
		postsListPage.status("-- All --");
		
		assertEquals(postsListPage.isPostInListImportant("-- All --"), true);
		assertEquals(postsListPage.isPostInListStatus("-- All --"), true);
	}
	
	@Test
	public void tc127SelectImportantAllAndStatusEnabled() {
		postsListPage.important("-- All --");
		postsListPage.status("enabled");
		
		assertEquals(postsListPage.isPostInListImportant("-- All --"), true);
		assertEquals(postsListPage.isPostInListStatus("enabled"), true);
	}
	
	@Test
	public void tc128SelectImportantAllAndStatusDisabled() {
		postsListPage.important("-- All --");
		postsListPage.status("disabled");
		
		assertEquals(postsListPage.isPostInListImportant("-- All --"), true);
		assertEquals(postsListPage.isPostInListStatus("disabled"), true);
	}
	
	@Test
	public void tc129SelectImportantYesAndStatusAll() {
		postsListPage.important("yes");
		postsListPage.status("-- All --");
		
		assertEquals(postsListPage.isPostInListImportant("yes"), true);
		assertEquals(postsListPage.isPostInListStatus("-- All --"), true);
	}
	
	@Test
	public void tc130SelectImportantYesAndStatusEnabled() {
		postsListPage.important("yes");
		postsListPage.status("enabled");
		
		assertEquals(postsListPage.isPostInListImportant("yes"), true);
		assertEquals(postsListPage.isPostInListStatus("enabled"), true);
	}
	
	@Test
	public void tc131SelectImportantYesAndStatusDisabled() {
		postsListPage.important("yes");
		postsListPage.status("disabled");
		
		assertEquals(postsListPage.isPostInListImportant("yes"), true);
		assertEquals(postsListPage.isPostInListStatus("disabled"), true);
	}
	
	@Test
	public void tc132SelectImportantNoAndStatusAll() {
		postsListPage.important("no");
		postsListPage.status("-- All --");
		
		assertEquals(postsListPage.isPostInListImportant("no"), true);
		assertEquals(postsListPage.isPostInListStatus("-- All --"), true);
	}
	
	@Test
	public void tc133SelectImportantNoAndStatusEnabled() {
		postsListPage.important("no");
		postsListPage.status("enabled");
		
		assertEquals(postsListPage.isPostInListImportant("no"), true);
		assertEquals(postsListPage.isPostInListStatus("enabled"), true);
	}
	
	@Test
	public void tc134SelectImportantNoAndStatusDisabled() {
		postsListPage.important("no");
		postsListPage.status("disabled");
		
		assertEquals(postsListPage.isPostInListImportant("no"), true);
		assertEquals(postsListPage.isPostInListStatus("disabled"), true);
	}
	
	@Test
	public void tc135SelectImportantAllAndWithTag() {
		postsListPage.important("-- All --");
		postsListPage.withTag("eos");
		
		assertEquals(postsListPage.isPostInListImportant("-- All --"), true);
		assertEquals(postsListPage.isPostInListWithTag("eos"), true);
	}
	
	@Test
	public void tc136SelectImportantAllAndWithTag() {
		postsListPage.important("-- All --");
		postsListPage.withTag("sit");
		
		assertEquals(postsListPage.isPostInListImportant("-- All --"), true);
		assertEquals(postsListPage.isPostInListWithTag("sit"), true);
	}
	
	@Test
	public void tc137SelectImportantAllAndWithTag() {
		postsListPage.important("-- All --");
		postsListPage.withTag("Vuk");
		
		assertEquals(postsListPage.isPostInListImportant("-- All --"), true);
		assertEquals(postsListPage.isPostInListWithTag("Vuk"), true);
	}
	
	@Test
	public void tc138SelectImportantYesAndWithTag() {
		postsListPage.important("yes");
		postsListPage.withTag("eos");
		
		assertEquals(postsListPage.isPostInListImportant("yes"), true);
		assertEquals(postsListPage.isPostInListWithTag("eos"), true);
	}
	@Test
	public void tc139SelectImportantYesAndWithTag() {
		postsListPage.important("yes");
		postsListPage.withTag("Tag 1983");
		
		assertEquals(postsListPage.noMatchingRecordsMessage(), "No matching records found");
	}
	
	@Test
	public void tc140SelectImportantYesAndWithTag() {
		postsListPage.important("yes");
		postsListPage.withTag("Default TAG");
		
		assertEquals(postsListPage.noMatchingRecordsMessage(), "No matching records found");
	}
	
	@Test
	public void tc141SelectImportantNoAndWithTag() {
		postsListPage.important("no");
		postsListPage.withTag("eos");
		
		assertEquals(postsListPage.isPostInListImportant("no"), true);
		assertEquals(postsListPage.isPostInListWithTag("eos"), true);
	}
	
	@Test
	public void tc142SelectImportantNoAndWithTag() {
		postsListPage.important("no");
		postsListPage.withTag("sit");
		
		assertEquals(postsListPage.isPostInListImportant("no"), true);
		assertEquals(postsListPage.isPostInListWithTag("sit"), true);
	}
	
	@Test
	public void tc143SelectImportantNoAndWithTag() {
		postsListPage.important("no");
		postsListPage.withTag("Vuk");
		
		assertEquals(postsListPage.isPostInListImportant("no"), true);
		assertEquals(postsListPage.isPostInListWithTag("Vuk"), true);
	}
	
	@Test
	public void tc144SelectStatusAll() {
		postsListPage.status("-- All --");
		
		assertEquals(postsListPage.isPostInListStatus("-- All --"), true);
	}
	
	@Test
	public void tc145SelectStatusEnabled() {
		postsListPage.status("enabled");
		
		assertEquals(postsListPage.isPostInListStatus("enabled"), true);
	}
	
	@Test
	public void tc146SelectStatusDisabled() {
		postsListPage.status("disabled");
		
		assertEquals(postsListPage.isPostInListStatus("disabled"), true);
	}
	
	@Test
	public void tc147SelectStatusAllAndWithTag() {
		postsListPage.status("-- All --");
		postsListPage.withTag("eos");
		
		assertEquals(postsListPage.isPostInListStatus("-- All --"), true);
		assertEquals(postsListPage.isPostInListWithTag("eos"), true);
	}
	
	@Test
	public void tc148SelectStatusAllAndWithTag() {
		postsListPage.status("-- All --");
		postsListPage.withTag("sit");
		
		assertEquals(postsListPage.isPostInListStatus("-- All --"), true);
		assertEquals(postsListPage.isPostInListWithTag("sit"), true);
	}
	
	@Test
	public void tc149SelectStatusAllAndWithTag() {
		postsListPage.status("-- All --");
		postsListPage.withTag("Vuk");
		
		assertEquals(postsListPage.isPostInListStatus("-- All --"), true);
		assertEquals(postsListPage.isPostInListWithTag("Vuk"), true);
	}
	
	@Test
	public void tc150SelectStatusEnabledAndWithTag() {
		postsListPage.status("enabled");
		postsListPage.withTag("eos");
		
		assertEquals(postsListPage.isPostInListStatus("enabled"), true);
		assertEquals(postsListPage.isPostInListWithTag("eos"), true);
	}
	
	@Test
	public void tc151SelectStatusEnabledAndWithTag() {
		postsListPage.status("enabled");
		postsListPage.withTag("sit");
		
		assertEquals(postsListPage.isPostInListStatus("enabled"), true);
		assertEquals(postsListPage.isPostInListWithTag("sit"), true);
	}
	
	@Test
	public void tc152SelectStatusEnabledAndWithTag() {
		postsListPage.status("enabled");
		postsListPage.withTag("Tag name 57");
		
		assertEquals(postsListPage.noMatchingRecordsMessage(), "No matching records found");
	}
	
	@Test
	public void tc153SelectStatusDisabledAndWithTag() {
		postsListPage.status("disabled");
		postsListPage.withTag("eos");
		
		assertEquals(postsListPage.noMatchingRecordsMessage(), "No matching records found");
	}
	
	@Test
	public void tc154SelectStatusDisabledAndWithTag() {
		postsListPage.status("disabled");
		postsListPage.withTag("Tag name 57");
		
		assertEquals(postsListPage.noMatchingRecordsMessage(), "No matching records found");
	}
	
	@Test
	public void tc155SelectStatusEnabledAndWithTag() {
		postsListPage.status("disabled");
		postsListPage.withTag("Vuk");
		
		assertEquals(postsListPage.isPostInListStatus("disabled"), true);
		assertEquals(postsListPage.isPostInListWithTag("Vuk"), true);
	}
	
	@Test
	public void tc156SelectWithTag() {
		postsListPage.withTag("eos");
		
		assertEquals(postsListPage.isPostInListWithTag("eos"), true);
	}
	
	@Test
	public void tc157SelectWithTag() {
		postsListPage.withTag("sit");
		
		assertEquals(postsListPage.isPostInListWithTag("sit"), true);
	}
	
	@Test
	public void tc158SelectWithTag() {
		postsListPage.withTag("Vuk");
		
		assertEquals(postsListPage.isPostInListWithTag("Vuk"), true);
	}
	
	@Test
	public void tc159showEntries() {
		postsListPage.showEntries("10");
		
		assertEquals(postsListPage.entriesList("10"), true);
	}
	

	@Test
	public void tc160showEntries() {
		postsListPage.showEntries("25");
		
		assertEquals(postsListPage.entriesList("25"), true);
	}
	
	@Test
	public void tc161showEntries() {
		postsListPage.showEntries("50");
		
		assertEquals(postsListPage.entriesList("50"), true);
	}
	
	@Test
	public void tc162showEntries() {
		postsListPage.showEntries("100");
		
		assertEquals(postsListPage.entriesList("100"), true);
	}
	
	@Test
	public void tc163searchPost() {
		postsListPage.search("70s music rare soul al green");
		
		
	}

	@Test
	public void tc164searchPost() {
		postsListPage.search("Avion");
		
		assertEquals(postsListPage.noMatchingRecordsMessage(), "No matching records found");
	}
	
	@Test
	public void tc165searchPost() {
		postsListPage.search("Title");
		
		assertEquals(postsListPage.isPostInListContainingTitleText(), true);
	}
	
	@Test
	public void tc166viewPostButton() {
		postsListPage.title("Lorem Ipsum is not simply dummy text");
		postsListPage.viewPost();
		
		driver.getWindowHandles().forEach(tab->driver.switchTo().window(tab));
		assertEquals(driver.getCurrentUrl(), "https://testblog.kurs-qa.cubes.edu.rs/posts/single-post/1355/lorem-ipsum-is-not-simply-dummy-text");
	}
	
	@Test
	public void tc167updatePostButton() {
		postsListPage.title(" Lorem Ipsum is not simply dummy text");
		postsListPage.updatePost();
		
		
		assertEquals(driver.getCurrentUrl(), "https://testblog.kurs-qa.cubes.edu.rs/admin/posts/edit/1355");
	
	}
	
	@Test
	public void tc168updateCategory() {
		postsListPage.title(" Lorem Ipsum is not simply dummy text");
		postsListPage.updatePost();
		
		addPostPage.chooseCategory("Clarkstad");
		addPostPage.savePost();
		
		assertEquals(postsListPage.updateMessage(), "Post has been edited");
	}
	
	@Test
	public void tc169updateCategoryCancel() {
		postsListPage.title("Lorem Ipsum is not simply dummy text");
		postsListPage.updatePost();
		
		addPostPage.chooseCategory("Clarkstad");
		addPostPage.cancelPost();
		
		assertEquals(driver.getCurrentUrl(), "https://testblog.kurs-qa.cubes.edu.rs/admin/posts");
		
	}
	
	@Test
	public void tc170updatePostWithOutTitle() {
		postsListPage.title("Lorem Ipsum is not simply dummy text");
		postsListPage.updatePost();
		
		addPostPage.title("");
		addPostPage.savePost();
		
		assertEquals(addPostPage.titleErrorMessage(), "This field is required.");
	}

	@Test
	public void tc171updatePostWithTitleUnder20characters() {
		postsListPage.title(" Lorem Ipsum is not simply dummy text");
		postsListPage.updatePost();
		
		addPostPage.title("Random");
		addPostPage.savePost();
		
		assertEquals(addPostPage.titleErrorMessage(), "Please enter at least 20 characters.");
	}
	
	@Test
	public void tc172updatePostWithNewTitle() {
		postsListPage.title("Lorem Ipsum is not simply dummy text");
		postsListPage.updatePost();
		
		addPostPage.title("Lorem Ipsum is  simply dummy text");
		addPostPage.savePost();
		
		assertEquals(postsListPage.updateMessage(), "Post has been edited");
	}
	
	@Test
	public void tc173updatePostWithEmptyDescription() {
		postsListPage.title(" Lorem Ipsum is  simply dummy text");
		postsListPage.updatePost();
		
		addPostPage.description("");
		addPostPage.savePost();
		
		assertEquals(addPostPage.descriptionErrorMessage(), "This field is required.");
	}
	
	@Test
	public void tc174updatePostWithShortDescription() {
		postsListPage.title(" Lorem Ipsum is  simply dummy text");
		postsListPage.updatePost();
		
		addPostPage.description("Random");
		addPostPage.savePost();
		
		assertEquals(addPostPage.descriptionErrorMessage(), "Please enter at least 50 characters.");
	}
	
	@Test
	public void tc175updatePostWithNewDescription() {
		postsListPage.title(" Lorem Ipsum is  simply dummy text");
		postsListPage.updatePost();
		
		addPostPage.description("There are many variations of passages of Lorem Ipsum available");
		addPostPage.savePost();
		
		assertEquals(postsListPage.updateMessage(), "Post has been edited");
	}
	
	@Test
	public void tc176updatePostWithOutTags() {
		postsListPage.title(" Lorem Ipsum is  simply dummy text");
		postsListPage.updatePost();
		
		addPostPage.tags("Vuk");
		addPostPage.tags("sit");
		
		addPostPage.savePost();
		
		assertEquals(addPostPage.tagsErrorMessage(), "This field is required.");
	}
	
	@Test
	public void tc177updatePostWithNewTags() {
		postsListPage.title("Lorem Ipsum is  simply dummy text");
		postsListPage.updatePost();
		
		addPostPage.tags("Vuk");
		addPostPage.tags("sit");
		
		addPostPage.tags("Simba");
		addPostPage.tags("eos");
		
		addPostPage.savePost();
		
		assertEquals(postsListPage.updateMessage(), "Post has been edited");
	}
	
	@Test
	public void tc178UpdatePostWithOutContent() {
		postsListPage.title("Lorem Ipsum is  simply dummy text");
		postsListPage.updatePost();
		
		addPostPage.content("");
		
		addPostPage.savePost();
		
		assertEquals(addPostPage.contentErrorMesage(), "The content field is required.");
	}
	
	@Test
	public void tc179UpdatePostWithNewContent() {
		postsListPage.title("Lorem Ipsum is  simply dummy text");
		postsListPage.updatePost();
		
		addPostPage.content("Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old.");
		
		addPostPage.savePost();
		
		assertEquals(postsListPage.updateMessage(), "Post has been edited");
	}
	
	@Test
	public void tc180ClickOnDeletePostButtonThenOnCancelButton() {
		postsListPage.title("Lorem Ipsum is  simply dummy text");
		
		
		postsListPage.deletePostButton();
		postsListPage.deleteCancelButton();
		
		
		assertEquals(postsListPage.isPostInList("Lorem Ipsum is  simply dummy text"), true);
	}
	
	@Test
	public void tc181DeletePost() {
		
		postsListPage.title("The standard chunk of Lorem Ipsum");
		
		postsListPage.deletePostButton();
		postsListPage.deleteButton();
		
		assertEquals(postsListPage.updateMessage(), "Post has been deleted");
	}
	
	@Test
	public void tc182ClickOnDisablePostButtonThenOnCancelButton() {
		postsListPage.title("Lorem Ipsum is  simply dummy text");
		
		
		postsListPage.disablePostButton();
		postsListPage.disableCancelButton();
		
		
		assertEquals(postsListPage.isPostInList("Lorem Ipsum is  simply dummy text"), true);
	}
	
	@Test
	public void tc183DisablePost() {
		postsListPage.title("Lorem Ipsum is  simply dummy text");
		
		
		postsListPage.disablePostButton();
		postsListPage.disableButton();
		
		
	  assertEquals(postsListPage.updateMessage(),"Post has been disabled");
	}
	
	@Test
	public void tc184ClickonSetPostAsUnimportantThenOnCancel() {
		postsListPage.title("Lorem Ipsum is  simply dummy text");
		
		
		postsListPage.setPostAsUnimportant();
		postsListPage.unimportantCancelButton();
		
		
	 
	}
	
	@Test
	public void tc185SetPostAsUnimportant() {
		postsListPage.title("Lorem Ipsum is  simply dummy text");
	
		postsListPage.setPostAsUnimportant();
		postsListPage.unimportantButton();
		
		
	  assertEquals(postsListPage.updateMessage(), "Post has been set as Unimportant");
	}
	
	@Test
	public void tc186ClickOnEnablePostThenOnCancelButton() {
		postsListPage.title("Lorem Ipsum is  simply dummy text");
		
		postsListPage.enablePost();
		postsListPage.enableCanCelButton();

	}
	
	@Test
	public void tc187enablePost() {
		postsListPage.title("Lorem Ipsum is  simply dummy text");
		
		postsListPage.enablePost();
		postsListPage.enableButton();
		
		 assertEquals(postsListPage.updateMessage(), "Post has been enabled");

	}
	
	@Test
	public void tc188ClickOnSetPostAsImportantThenClickOnCanlecButton() {
		postsListPage.title("Lorem Ipsum is  simply dummy text");
		
		postsListPage.setPostAsImportant();
		postsListPage.importantCancelButton();
	
	}
	
	@Test
	public void tc189SetPostAsImportant() {
		postsListPage.title("Lorem Ipsum is  simply dummy text");
		
		postsListPage.setPostAsImportant();
		postsListPage.importantButton();
		
		 assertEquals(postsListPage.updateMessage(), "Post has been set as important");
	
	}
	
	@Test
	public void tc190Nextpage() {
		
		postsListPage.nextPage();
	}
	
	@Test
	public void tc191PreviousPage() {
		
		postsListPage.previousPage();
	}
	
	@Test
	public void tc192Page3() {
		
		postsListPage.page3();
	}
	
	@Test
	public void tc193Page2() {
		
		postsListPage.page2();
	}
	
	@Test
	public void tc194Page1() {
		
		postsListPage.page1();
	}
	
	@Test
	public void tc195AddNewPostButton() {
		
		postsListPage.addNewPost();
		
		assertEquals(driver.getCurrentUrl(), "https://testblog.kurs-qa.cubes.edu.rs/admin/posts/add");
	}
	
	@Test
	public void tc196Home() {
		
		postsListPage.home();
		
		assertEquals(driver.getCurrentUrl(), "https://testblog.kurs-qa.cubes.edu.rs/admin");
	}
	
	@Test
	public void tc197SideBarMenu() {
		
		postsListPage.navigation();
	
	}
	
	@Test
	public void tc198Logout() {
		postsListPage.logout();
		
		assertEquals(driver.getCurrentUrl(), "https://testblog.kurs-qa.cubes.edu.rs/login");
	}






}
