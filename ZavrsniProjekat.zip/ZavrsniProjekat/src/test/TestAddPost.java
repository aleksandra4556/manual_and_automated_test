package test;

import static org.junit.Assert.*;

import java.time.Duration;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.WebDriverWait;

import webpages.AddPostPage;
import webpages.LoginPage;
import webpages.PostsListPage;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TestAddPost {


	private static ChromeDriver driver;
	private static LoginPage loginPage;
	private static AddPostPage addPostPage;
	private static PostsListPage postsListPage;

	
	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		System.setProperty("Webdriver.chrome.driver", "I:\\Users\\jovan\\Desktop/webdriver/chromdriver");
		ChromeOptions options = new ChromeOptions();
		options.addArguments("--remote-allow-origins=*");
		driver = new ChromeDriver(options);
	    WebDriverWait driverWait = new WebDriverWait(driver, Duration.ofMillis(10000));
	    
	    loginPage = new LoginPage(driver);
	    addPostPage = new AddPostPage(driver, driverWait);
	    postsListPage = new PostsListPage(driver, driverWait);
	    loginPage.loginSuccess();
	    
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
		addPostPage.openPage();
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void tc03ChooseCategory() {
		
		addPostPage.chooseCategory("Clarkstad");
		addPostPage.savePost();
		
		assertEquals(addPostPage.titleErrorMessage(), "This field is required.");
		assertEquals(addPostPage.descriptionErrorMessage(), "This field is required.");
		assertEquals(addPostPage.tagsErrorMessage(), "This field is required.");
		assertEquals(addPostPage.contentErrorMesage(), "The content field is required.");
	}
	
	@Test
	public void tc04ChooseCategoryAndShortTitle() {
		
		addPostPage.chooseCategory("Clarkstad");
		addPostPage.title("Random");
		addPostPage.savePost();
	
		assertEquals(addPostPage.titleErrorMessage(), "Please enter at least 20 characters.");
		assertEquals(addPostPage.descriptionErrorMessage(), "This field is required.");
		assertEquals(addPostPage.tagsErrorMessage(), "This field is required.");
		assertEquals(addPostPage.contentErrorMesage(), "The content field is required.");
	}
	
	@Test
	public void tc05ChooseCategoryAndTitle() {
		
		addPostPage.chooseCategory("Clarkstad");
		addPostPage.title("Lorem Ipsum is simply dummy text");
		addPostPage.savePost();
	
		assertEquals(addPostPage.descriptionErrorMessage(), "This field is required.");
		assertEquals(addPostPage.tagsErrorMessage(), "This field is required.");
		assertEquals(addPostPage.contentErrorMesage(), "The content field is required.");
	}
	
	@Test
	public void tc06ChooseCategoryAndShortDescription() {
		
		addPostPage.chooseCategory("Clarkstad");
		addPostPage.description("Random");
		addPostPage.savePost();
	
		assertEquals(addPostPage.titleErrorMessage(), "This field is required.");
		assertEquals(addPostPage.descriptionErrorMessage(), "Please enter at least 50 characters.");
		assertEquals(addPostPage.tagsErrorMessage(), "This field is required.");
		assertEquals(addPostPage.contentErrorMesage(), "The content field is required.");
	}
	
	@Test
	public void tc07ChooseCategoryAndDescription() {
		
		addPostPage.chooseCategory("Clarkstad");
		addPostPage.description("The standard chunk of Lorem Ipsum used since the 1500s is reproduced below");
		addPostPage.savePost();
	
		assertEquals(addPostPage.titleErrorMessage(), "This field is required.");
		assertEquals(addPostPage.tagsErrorMessage(), "This field is required.");
		assertEquals(addPostPage.contentErrorMesage(), "The content field is required.");
	}
	
	@Test
	public void tc08ChooseCategoryAndImportantNo() {
		
		addPostPage.chooseCategory("Clarkstad");
		addPostPage.savePost();
	
		assertEquals(addPostPage.titleErrorMessage(), "This field is required.");
		assertEquals(addPostPage.descriptionErrorMessage(), "This field is required.");
		assertEquals(addPostPage.tagsErrorMessage(), "This field is required.");
		assertEquals(addPostPage.contentErrorMesage(), "The content field is required.");
	}
	
	@Test
	public void tc09ChooseCategoryAndImportantYes() {
		
		addPostPage.chooseCategory("Clarkstad");
		addPostPage.importantYes();
		addPostPage.savePost();
	
		assertEquals(addPostPage.titleErrorMessage(), "This field is required.");
		assertEquals(addPostPage.descriptionErrorMessage(), "This field is required.");
		assertEquals(addPostPage.tagsErrorMessage(), "This field is required.");
		assertEquals(addPostPage.contentErrorMesage(), "The content field is required.");
	}
	
	@Test
	public void tc10ChooseCategoryAndOneTag() {
		
		addPostPage.chooseCategory("Clarkstad");
		addPostPage.tags("Vuk");
		addPostPage.savePost();
	
		assertEquals(addPostPage.titleErrorMessage(), "This field is required.");
		assertEquals(addPostPage.descriptionErrorMessage(), "This field is required.");
		assertEquals(addPostPage.contentErrorMesage(), "The content field is required.");
	}
	
	@Test
	public void tc11ChooseCategoryAndMultipleTags() {
		
		addPostPage.chooseCategory("Clarkstad");
		addPostPage.tags("Vuk");
		addPostPage.tags("sit");
		addPostPage.tags("NEW Tag782");
		addPostPage.tags("VladimirQA_NE_BRISI!");
		addPostPage.savePost();
	
		assertEquals(addPostPage.titleErrorMessage(), "This field is required.");
		assertEquals(addPostPage.descriptionErrorMessage(), "This field is required.");
		assertEquals(addPostPage.contentErrorMesage(), "The content field is required.");
	}
	
	@Test
	public void tc12ChooseCategoryAndPhoto() {
		addPostPage.chooseCategory("Clarkstad");
		addPostPage.addPhoto();
		addPostPage.savePost();
		
		assertEquals(addPostPage.titleErrorMessage(), "This field is required.");
		assertEquals(addPostPage.descriptionErrorMessage(), "This field is required.");
		assertEquals(addPostPage.tagsErrorMessage(), "This field is required.");
		assertEquals(addPostPage.contentErrorMesage(), "The content field is required.");
	}
	
	@Test
	public void tc13ChooseCategoryAndFileInContent() {
		addPostPage.chooseCategory("Clarkstad");
		addPostPage.content("It is a long established fact that a reader will be distracted by the readable content");
		addPostPage.savePost();
		
		assertEquals(addPostPage.titleErrorMessage(), "This field is required.");
		assertEquals(addPostPage.descriptionErrorMessage(), "This field is required.");
		assertEquals(addPostPage.tagsErrorMessage(), "This field is required.");
	}
	
	@Test
	public void tc14ShortTitleAndDescription() {
		addPostPage.title("Random");
		addPostPage.description("Random");
		addPostPage.savePost();
		
		assertEquals(addPostPage.titleErrorMessage(), "Please enter at least 20 characters.");
		assertEquals(addPostPage.descriptionErrorMessage(), "Please enter at least 50 characters.");
		assertEquals(addPostPage.tagsErrorMessage(), "This field is required.");
		assertEquals(addPostPage.contentErrorMesage(), "The content field is required.");
	}
	
	@Test
	public void tc15TitleAndDescription() {
		addPostPage.title(" Lorem Ipsum is simply dummy text");
		addPostPage.description("The standard chunk of Lorem Ipsum used since the 1500s is reproduced below");
		addPostPage.savePost();
		
		assertEquals(addPostPage.tagsErrorMessage(), "This field is required.");
		assertEquals(addPostPage.contentErrorMesage(), "The content field is required.");
	}
	
	@Test
	public void tc16ShortTitleAndImportantNo() {
		addPostPage.title("Random");
		addPostPage.savePost();
		
		assertEquals(addPostPage.titleErrorMessage(), "Please enter at least 20 characters.");
		assertEquals(addPostPage.descriptionErrorMessage(), "This field is required.");
		assertEquals(addPostPage.tagsErrorMessage(), "This field is required.");
		assertEquals(addPostPage.contentErrorMesage(), "The content field is required.");
	}
	
	@Test
	public void tc17ShortTitleAndImportantYes() {
		addPostPage.title("Random");
		addPostPage.importantYes();
		addPostPage.savePost();
		
		assertEquals(addPostPage.titleErrorMessage(), "Please enter at least 20 characters.");
		assertEquals(addPostPage.descriptionErrorMessage(), "This field is required.");
		assertEquals(addPostPage.tagsErrorMessage(), "This field is required.");
		assertEquals(addPostPage.contentErrorMesage(), "The content field is required.");
	}
	
	@Test
	public void tc18TitleAndImportantNo() {
		addPostPage.title("Lorem Ipsum is simply dummy text");
		addPostPage.savePost();
		
		assertEquals(addPostPage.descriptionErrorMessage(), "This field is required.");
		assertEquals(addPostPage.tagsErrorMessage(), "This field is required.");
		assertEquals(addPostPage.contentErrorMesage(), "The content field is required.");
	}
	
	@Test
	public void tc19TitleAndImportantYes() {
		addPostPage.title("Lorem Ipsum is simply dummy text");
		addPostPage.importantYes();
		addPostPage.savePost();
		
		assertEquals(addPostPage.descriptionErrorMessage(), "This field is required.");
		assertEquals(addPostPage.tagsErrorMessage(), "This field is required.");
		assertEquals(addPostPage.contentErrorMesage(), "The content field is required.");
	}
	
	@Test
	public void tc20ShortTitleAndWithTag() {
		addPostPage.title("Random");
		addPostPage.tags("Vuk");
		addPostPage.tags("sit");
		addPostPage.savePost();
		
		assertEquals(addPostPage.titleErrorMessage(), "Please enter at least 20 characters.");
		assertEquals(addPostPage.descriptionErrorMessage(), "This field is required.");
		assertEquals(addPostPage.contentErrorMesage(), "The content field is required.");
	}
	
	@Test
	public void tc21TitleAndWithTag() {
		addPostPage.title("Lorem Ipsum is simply dummy text");
		addPostPage.tags("Vuk");
		addPostPage.tags("sit");
		addPostPage.savePost();
		
		assertEquals(addPostPage.descriptionErrorMessage(), "This field is required.");
		assertEquals(addPostPage.contentErrorMesage(), "The content field is required.");
	}
	
	@Test
	public void tc22ShortTitleAndWithPhoto() {
		addPostPage.title("Random");
		addPostPage.addPhoto();
		addPostPage.savePost();
		
		assertEquals(addPostPage.titleErrorMessage(), "Please enter at least 20 characters.");
		assertEquals(addPostPage.descriptionErrorMessage(), "This field is required.");
		assertEquals(addPostPage.tagsErrorMessage(), "This field is required.");
		assertEquals(addPostPage.contentErrorMesage(), "The content field is required.");
	}

	@Test
	public void tc23TitleAndWithPhoto() {
		addPostPage.title("Lorem Ipsum is simply dummy text");
		addPostPage.addPhoto();
		addPostPage.savePost();
		
		assertEquals(addPostPage.descriptionErrorMessage(), "This field is required.");
		assertEquals(addPostPage.tagsErrorMessage(), "This field is required.");
		assertEquals(addPostPage.contentErrorMesage(), "The content field is required.");
	}
	
	@Test
	public void tc24ShortTitleAndFieldInContent() {
		addPostPage.title("Random");
		addPostPage.content("It is a long established fact that a reader will be distracted by the readable content");
		addPostPage.savePost();
		
		assertEquals(addPostPage.titleErrorMessage(), "Please enter at least 20 characters.");
		assertEquals(addPostPage.descriptionErrorMessage(), "This field is required.");
		assertEquals(addPostPage.tagsErrorMessage(), "This field is required.");
	}
	
	@Test
	public void tc25TitleAndFieldInContent() {
		addPostPage.title("Lorem Ipsum is simply dummy text");
		addPostPage.content("It is a long established fact that a reader will be distracted by the readable content");
		addPostPage.savePost();
		
		assertEquals(addPostPage.descriptionErrorMessage(), "This field is required.");
		assertEquals(addPostPage.tagsErrorMessage(), "This field is required.");
	}
	
	@Test
	public void tc26ShortDescriptionAndImportantNo() {
		addPostPage.description("Random");
		addPostPage.savePost();
		
		assertEquals(addPostPage.titleErrorMessage(), "This field is required.");
		assertEquals(addPostPage.descriptionErrorMessage(), "Please enter at least 50 characters.");
		assertEquals(addPostPage.tagsErrorMessage(), "This field is required.");
		assertEquals(addPostPage.contentErrorMesage(), "The content field is required.");
	}
	
	@Test
	public void tc27ShortDescriptionAndImportantYes() {
		addPostPage.description("Random");
		addPostPage.importantYes();
		addPostPage.savePost();
		
		assertEquals(addPostPage.titleErrorMessage(), "This field is required.");
		assertEquals(addPostPage.descriptionErrorMessage(), "Please enter at least 50 characters.");
		assertEquals(addPostPage.tagsErrorMessage(), "This field is required.");
		assertEquals(addPostPage.contentErrorMesage(), "The content field is required.");
	}
	
	@Test
	public void tc28DescriptionAndImportantNo() {
		addPostPage.description("The standard chunk of Lorem Ipsum used since the 1500s is reproduced below");
		addPostPage.savePost();
		
		assertEquals(addPostPage.titleErrorMessage(), "This field is required.");
		assertEquals(addPostPage.tagsErrorMessage(), "This field is required.");
		assertEquals(addPostPage.contentErrorMesage(), "The content field is required.");
	}
	
	@Test
	public void tc29DescriptionAndImportantYes() {
		addPostPage.description("The standard chunk of Lorem Ipsum used since the 1500s is reproduced below");
		addPostPage.importantYes();
		addPostPage.savePost();
		
		assertEquals(addPostPage.titleErrorMessage(), "This field is required.");
		assertEquals(addPostPage.tagsErrorMessage(), "This field is required.");
		assertEquals(addPostPage.contentErrorMesage(), "The content field is required.");
	}
	
	@Test
	public void tc30ShortDescriptionAndWithTag() {
		addPostPage.description("Random");
		addPostPage.tags("Vuk");
		addPostPage.tags("sit");
		addPostPage.savePost();
		
		assertEquals(addPostPage.titleErrorMessage(), "This field is required.");
		assertEquals(addPostPage.descriptionErrorMessage(), "Please enter at least 50 characters.");
		assertEquals(addPostPage.contentErrorMesage(), "The content field is required.");
	}
	
	@Test
	public void tc31DescriptionAndWithTag() {
		addPostPage.description("The standard chunk of Lorem Ipsum used since the 1500s is reproduced below");
		addPostPage.tags("Vuk");
		addPostPage.tags("sit");
		addPostPage.savePost();
		
		assertEquals(addPostPage.titleErrorMessage(), "This field is required.");
		assertEquals(addPostPage.contentErrorMesage(), "The content field is required.");
	}
	
	@Test
	public void tc32ShortDescriptionAndWithPhoto() {
		addPostPage.description("Random");
		addPostPage.addPhoto();
		addPostPage.savePost();
		
		assertEquals(addPostPage.titleErrorMessage(), "This field is required.");
		assertEquals(addPostPage.descriptionErrorMessage(), "Please enter at least 50 characters.");
		assertEquals(addPostPage.tagsErrorMessage(), "This field is required.");
		assertEquals(addPostPage.contentErrorMesage(), "The content field is required.");
	}
	
	@Test
	public void tc33DescriptionAndWithPhoto() {
		addPostPage.description("The standard chunk of Lorem Ipsum used since the 1500s is reproduced below");
		addPostPage.addPhoto();
		addPostPage.savePost();
		
		assertEquals(addPostPage.titleErrorMessage(), "This field is required.");
		assertEquals(addPostPage.tagsErrorMessage(), "This field is required.");
		assertEquals(addPostPage.contentErrorMesage(), "The content field is required.");
	}
	@Test
	public void tc34ShortDescriptionAndFieldinContent() {
		addPostPage.description("Random");
		addPostPage.content("It is a long established fact that a reader will be distracted by the readable content");
		addPostPage.savePost();
		
		assertEquals(addPostPage.titleErrorMessage(), "This field is required.");
		assertEquals(addPostPage.descriptionErrorMessage(), "Please enter at least 50 characters.");
		assertEquals(addPostPage.tagsErrorMessage(), "This field is required.");
	}
	
	@Test
	public void tc35DescriptionAndFieldinContent() {
		addPostPage.description("The standard chunk of Lorem Ipsum used since the 1500s is reproduced below");
		addPostPage.content("It is a long established fact that a reader will be distracted by the readable content");
		addPostPage.savePost();
		
		assertEquals(addPostPage.titleErrorMessage(), "This field is required.");
		assertEquals(addPostPage.tagsErrorMessage(), "This field is required.");
	}
	
	@Test
	public void tc36ImportantNoAndWithTag() {
		addPostPage.tags("Vuk");
		addPostPage.tags("sit");
		addPostPage.savePost();
		
		assertEquals(addPostPage.titleErrorMessage(), "This field is required.");
		assertEquals(addPostPage.descriptionErrorMessage(), "This field is required.");
		assertEquals(addPostPage.contentErrorMesage(), "The content field is required.");
	}
	
	@Test
	public void tc37ImportantYesAndWithTag() {
		addPostPage.tags("Vuk");
		addPostPage.tags("sit");
		addPostPage.importantYes();
		addPostPage.savePost();
		
		assertEquals(addPostPage.titleErrorMessage(), "This field is required.");
		assertEquals(addPostPage.descriptionErrorMessage(), "This field is required.");
		assertEquals(addPostPage.contentErrorMesage(), "The content field is required.");
	}
	@Test
	public void tc38ImportantNoAndWithPhoto() {
		addPostPage.addPhoto();
		addPostPage.savePost();
		
		assertEquals(addPostPage.titleErrorMessage(), "This field is required.");
		assertEquals(addPostPage.descriptionErrorMessage(), "This field is required.");
		assertEquals(addPostPage.tagsErrorMessage(), "This field is required.");
		assertEquals(addPostPage.contentErrorMesage(), "The content field is required.");
	}
	
	@Test
	public void tc39ImportantYesAndWithPhoto() {
		addPostPage.addPhoto();
		addPostPage.importantYes();
		addPostPage.savePost();
		
		assertEquals(addPostPage.titleErrorMessage(), "This field is required.");
		assertEquals(addPostPage.descriptionErrorMessage(), "This field is required.");
		assertEquals(addPostPage.tagsErrorMessage(), "This field is required.");
		assertEquals(addPostPage.contentErrorMesage(), "The content field is required.");
	}
	
	@Test
	public void tc40ImportantNoAndWithFieldInContent() {
		addPostPage.content("It is a long established fact that a reader will be distracted by the readable content");
		addPostPage.savePost();
		
		assertEquals(addPostPage.titleErrorMessage(), "This field is required.");
		assertEquals(addPostPage.descriptionErrorMessage(), "This field is required.");
		assertEquals(addPostPage.tagsErrorMessage(), "This field is required.");
	}
	
	@Test
	public void tc41ImportantYesAndWithFieldInContent() {
		addPostPage.importantYes();
		addPostPage.content("It is a long established fact that a reader will be distracted by the readable content");
		addPostPage.savePost();
		
		assertEquals(addPostPage.titleErrorMessage(), "This field is required.");
		assertEquals(addPostPage.descriptionErrorMessage(), "This field is required.");
		assertEquals(addPostPage.tagsErrorMessage(), "This field is required.");
	}
	
	@Test
	public void tc42CategoryAndShortTitleCancelPost() {
		addPostPage.chooseCategory("Clarkstad");
		addPostPage.title("Random");
		addPostPage.cancelPost();
		
		assertEquals(driver.getCurrentUrl(), "https://testblog.kurs-qa.cubes.edu.rs/admin/posts");
	}
	
	@Test
	public void tc43CategoryAndTitleCancelPost() {
		addPostPage.chooseCategory("Clarkstad");
		addPostPage.title("Lorem Ipsum is simply dummy text");
		addPostPage.cancelPost();
		
		assertEquals(driver.getCurrentUrl(), "https://testblog.kurs-qa.cubes.edu.rs/admin/posts");
	}
	
	@Test
	public void tc44CategoryAndShortDescriptionCancelPost() {
		addPostPage.chooseCategory("Clarkstad");
		addPostPage.description("Random");
		addPostPage.cancelPost();
		
		assertEquals(driver.getCurrentUrl(), "https://testblog.kurs-qa.cubes.edu.rs/admin/posts");
	}
	
	@Test
	public void tc45CategoryAndDescriptionCancelPost() {
		addPostPage.chooseCategory("Clarkstad");
		addPostPage.description("The standard chunk of Lorem Ipsum used since the 1500s is reproduced below");
		addPostPage.cancelPost();
		
		assertEquals(driver.getCurrentUrl(), "https://testblog.kurs-qa.cubes.edu.rs/admin/posts");
	}
	
	@Test
	public void tc46CategoryAndImportantNoCancelPost() {
		addPostPage.chooseCategory("Clarkstad");
		addPostPage.cancelPost();
		
		assertEquals(driver.getCurrentUrl(), "https://testblog.kurs-qa.cubes.edu.rs/admin/posts");
	}
	
	@Test
	public void tc47CategoryAndImportantYesCancelPost() {
		addPostPage.chooseCategory("Clarkstad");
		addPostPage.importantYes();
		addPostPage.cancelPost();
		
		assertEquals(driver.getCurrentUrl(), "https://testblog.kurs-qa.cubes.edu.rs/admin/posts");
	}
	
	@Test
	public void tc48CategoryAndTagCancelPost() {
		addPostPage.chooseCategory("Clarkstad");
		addPostPage.tags("Vuk");
		addPostPage.tags("sit");
		addPostPage.cancelPost();
		
		assertEquals(driver.getCurrentUrl(), "https://testblog.kurs-qa.cubes.edu.rs/admin/posts");
	}
	
	@Test
	public void tc49CategoryAndPhotoCancelPost() {
		addPostPage.chooseCategory("Clarkstad");
		addPostPage.addPhoto();
		addPostPage.cancelPost();
		
		assertEquals(driver.getCurrentUrl(), "https://testblog.kurs-qa.cubes.edu.rs/admin/posts");
	}
	
	@Test
	public void tc50CategoryAndContentFieldIn() {
		addPostPage.chooseCategory("Clarkstad");
		addPostPage.content("It is a long established fact that a reader will be distracted by the readable content");
        addPostPage.cancelPost();
		
		assertEquals(driver.getCurrentUrl(), "https://testblog.kurs-qa.cubes.edu.rs/admin/posts");
	}
	
	@Test
	public void tc51ShortTitleAndDescriptionCancelPost() {
		addPostPage.title("Random");
		addPostPage.description("Random");
		addPostPage.cancelPost();
		
		assertEquals(driver.getCurrentUrl(), "https://testblog.kurs-qa.cubes.edu.rs/admin/posts");
	}
	
	@Test
	public void tc52TitleAndDescriptionCancelPost() {
		addPostPage.title("Lorem Ipsum is simply dummy text");
		addPostPage.description("The standard chunk of Lorem Ipsum used since the 1500s is reproduced below");
		addPostPage.cancelPost();
		
		assertEquals(driver.getCurrentUrl(), "https://testblog.kurs-qa.cubes.edu.rs/admin/posts");
	}
	
	@Test
	public void tc53ShortTitleAndImportantNoCancelPost() {
		addPostPage.title("Random");
		addPostPage.cancelPost();
		
		assertEquals(driver.getCurrentUrl(), "https://testblog.kurs-qa.cubes.edu.rs/admin/posts");
	}
	
	@Test
	public void tc54ShortTitleAndImportantYesCancelPost() {
		addPostPage.title("Random");
		addPostPage.importantYes();
		addPostPage.cancelPost();
		
		assertEquals(driver.getCurrentUrl(), "https://testblog.kurs-qa.cubes.edu.rs/admin/posts");
	}
	
	@Test
	public void tc55TitleAndImportantNoCancelPost() {
		addPostPage.title("Lorem Ipsum is simply dummy text");
		addPostPage.cancelPost();
		
		assertEquals(driver.getCurrentUrl(), "https://testblog.kurs-qa.cubes.edu.rs/admin/posts");
	}
	
	@Test
	public void tc56TitleAndImportantYesCancelPost() {
		addPostPage.title("Lorem Ipsum is simply dummy text");
		addPostPage.importantYes();
		addPostPage.cancelPost();
		
		assertEquals(driver.getCurrentUrl(), "https://testblog.kurs-qa.cubes.edu.rs/admin/posts");
	}
	
	@Test
	public void tc57ShortTitleAndWithTagCancelPost() {
		addPostPage.title("Random");
		addPostPage.tags("Vuk");
		addPostPage.tags("sit");
		addPostPage.cancelPost();
		
		assertEquals(driver.getCurrentUrl(), "https://testblog.kurs-qa.cubes.edu.rs/admin/posts");
	}
	
	@Test
	public void tc58TitleAndWithTagCancelPost() {
		addPostPage.title("Lorem Ipsum is simply dummy text");
		addPostPage.tags("Vuk");
		addPostPage.tags("sit");
		addPostPage.cancelPost();
		
		assertEquals(driver.getCurrentUrl(), "https://testblog.kurs-qa.cubes.edu.rs/admin/posts");
	}
	
	@Test
	public void tc59ShortTitleAndWithPhotoCancelPost() {
		addPostPage.title("Random");
		addPostPage.addPhoto();
		addPostPage.cancelPost();
		
		assertEquals(driver.getCurrentUrl(), "https://testblog.kurs-qa.cubes.edu.rs/admin/posts");
	}
	
	@Test
	public void tc60TitleAndWithPhotoCancelPost() {
		addPostPage.title("Lorem Ipsum is simply dummy text");
		addPostPage.addPhoto();
		addPostPage.cancelPost();
		
		assertEquals(driver.getCurrentUrl(), "https://testblog.kurs-qa.cubes.edu.rs/admin/posts");
	}
	
	@Test
	public void tc61ShortTitleAndWithContentCancelPost() {
		addPostPage.title("Random");
		addPostPage.content("It is a long established fact that a reader will be distracted by the readable content");
		addPostPage.cancelPost();
		
		assertEquals(driver.getCurrentUrl(), "https://testblog.kurs-qa.cubes.edu.rs/admin/posts");
	}
	
	@Test
	public void tc62TitleAndWithPhotoCancelPost() {
		addPostPage.title("Lorem Ipsum is simply dummy text");
		addPostPage.content("It is a long established fact that a reader will be distracted by the readable content");
		addPostPage.cancelPost();
		
		assertEquals(driver.getCurrentUrl(), "https://testblog.kurs-qa.cubes.edu.rs/admin/posts");
	}
	
	@Test
	public void tc63ShortDescriptionAndImportantNoCancelPost() {
		addPostPage.description("Random");
		addPostPage.cancelPost();
		
		assertEquals(driver.getCurrentUrl(), "https://testblog.kurs-qa.cubes.edu.rs/admin/posts");
	}
	
	@Test
	public void tc64ShortDescriptionAndImportantYesCancelPost() {
		addPostPage.description("Random");
		addPostPage.importantYes();
		addPostPage.cancelPost();
		
		assertEquals(driver.getCurrentUrl(), "https://testblog.kurs-qa.cubes.edu.rs/admin/posts");
	}
	
	@Test
	public void tc65DescriptionAndImportantNoCancelPost() {
		addPostPage.description("The standard chunk of Lorem Ipsum used since the 1500s is reproduced below");
		addPostPage.cancelPost();
		
		assertEquals(driver.getCurrentUrl(), "https://testblog.kurs-qa.cubes.edu.rs/admin/posts");
	}
	
	@Test
	public void tc66DescriptionAndImportantYesCancelPost() {
		addPostPage.description("The standard chunk of Lorem Ipsum used since the 1500s is reproduced below");
		addPostPage.importantYes();
		addPostPage.cancelPost();
		
		assertEquals(driver.getCurrentUrl(), "https://testblog.kurs-qa.cubes.edu.rs/admin/posts");
	}
	
	@Test
	public void tc67ShortDescriptionAndWithTagCancelPost() {
		addPostPage.description("Random");
		addPostPage.tags("Vuk");
		addPostPage.tags("sit");
		addPostPage.cancelPost();
		
		assertEquals(driver.getCurrentUrl(), "https://testblog.kurs-qa.cubes.edu.rs/admin/posts");
	}
	
	@Test
	public void tc68DescriptionAndWithTagCancelPost() {
		addPostPage.description("The standard chunk of Lorem Ipsum used since the 1500s is reproduced below");
		addPostPage.tags("Vuk");
		addPostPage.tags("sit");
		addPostPage.cancelPost();
		
		assertEquals(driver.getCurrentUrl(), "https://testblog.kurs-qa.cubes.edu.rs/admin/posts");
	}
	
	@Test
	public void tc69ShortDescriptionAndWithPhotoCancelPost() {
		addPostPage.description("Random");
		addPostPage.addPhoto();
		addPostPage.cancelPost();
		
		assertEquals(driver.getCurrentUrl(), "https://testblog.kurs-qa.cubes.edu.rs/admin/posts");
	}
	
	@Test
	public void tc70DescriptionAndWithPhotoCancelPost() {
		addPostPage.description("The standard chunk of Lorem Ipsum used since the 1500s is reproduced below");
		addPostPage.addPhoto();
		addPostPage.cancelPost();
		
		assertEquals(driver.getCurrentUrl(), "https://testblog.kurs-qa.cubes.edu.rs/admin/posts");
	}
	
	@Test
	public void tc71ShortDescriptionAndWithContentCancelPost() {
		addPostPage.description("Random");
		addPostPage.content("It is a long established fact that a reader will be distracted by the readable content");
		addPostPage.cancelPost();
		
		assertEquals(driver.getCurrentUrl(), "https://testblog.kurs-qa.cubes.edu.rs/admin/posts");
	}
	
	@Test
	public void tc72DescriptionAndWithContentCancelPost() {
		addPostPage.description("The standard chunk of Lorem Ipsum used since the 1500s is reproduced below");
		addPostPage.content("It is a long established fact that a reader will be distracted by the readable content");
		addPostPage.cancelPost();
		
		assertEquals(driver.getCurrentUrl(), "https://testblog.kurs-qa.cubes.edu.rs/admin/posts");
	}
	
	@Test
	public void tc73ImportantNoAndWithTagCancelPost() {
		addPostPage.tags("Vuk");
		addPostPage.tags("sit");
		addPostPage.cancelPost();
		
		assertEquals(driver.getCurrentUrl(), "https://testblog.kurs-qa.cubes.edu.rs/admin/posts");
	}
	
	@Test
	public void tc74ImportantYesAndWithTagCancelPost() {
		addPostPage.importantYes();
		addPostPage.tags("Vuk");
		addPostPage.tags("sit");
		addPostPage.cancelPost();
		
		assertEquals(driver.getCurrentUrl(), "https://testblog.kurs-qa.cubes.edu.rs/admin/posts");
	}
	
	@Test
	public void tc75ImportantNoAndWithPhotoCancelPost() {
		addPostPage.addPhoto();
		addPostPage.cancelPost();
		
		assertEquals(driver.getCurrentUrl(), "https://testblog.kurs-qa.cubes.edu.rs/admin/posts");
	}
	
	@Test
	public void tc76ImportantYesAndWithPhotoCancelPost() {
		addPostPage.importantYes();
		addPostPage.addPhoto();
		addPostPage.cancelPost();
		
		assertEquals(driver.getCurrentUrl(), "https://testblog.kurs-qa.cubes.edu.rs/admin/posts");
	}
	
	@Test
	public void tc77ImportantNoAndWithContentCancelPost() {
		addPostPage.content("It is a long established fact that a reader will be distracted by the readable content");
		addPostPage.cancelPost();
		
		assertEquals(driver.getCurrentUrl(), "https://testblog.kurs-qa.cubes.edu.rs/admin/posts");
	}
	
	@Test
	public void tc78ImportantYesAndWithContentCancelPost() {
		addPostPage.importantYes();
		addPostPage.content("It is a long established fact that a reader will be distracted by the readable content");
		addPostPage.cancelPost();
		
		assertEquals(driver.getCurrentUrl(), "https://testblog.kurs-qa.cubes.edu.rs/admin/posts");
	}
	
	@Test
	public void tc79LeaveContentEmpty() {
		addPostPage.chooseCategory("Clarkstad");
		addPostPage.title("Lorem Ipsum is simply dummy  text");
		addPostPage.description("The standard chunk of Lorem Ipsum used since the 1500s is reproduced below");
		addPostPage.importantYes();
		addPostPage.tags("Vuk");
		addPostPage.tags("sit");
		addPostPage.savePost();
		
		assertEquals(addPostPage.contentErrorMesage(),"The content field is required.");
	}
	
	@Test
	public void tc80FileEverthingInThenCancelPost() {
		addPostPage.chooseCategory("Clarkstad");
		addPostPage.title("Lorem Ipsum is simply dummy  text");
		addPostPage.description("The standard chunk of Lorem Ipsum used since the 1500s is reproduced below");
		addPostPage.importantYes();
		addPostPage.tags("Vuk");
		addPostPage.tags("sit");
		addPostPage.content("It is a long established fact that a reader will be distracted by the readable content");
		addPostPage.cancelPost();
		
		assertEquals(driver.getCurrentUrl(), "https://testblog.kurs-qa.cubes.edu.rs/admin/posts");
	}
	
	@Test
	public void tc81AddPost() {
		addPostPage.chooseCategory("Clarkstad");
		addPostPage.title("Lorem Ipsum Lorem Ipsum");
		addPostPage.description("The standard chunk of Lorem Ipsum used since the 1500s is reproduced below");
		addPostPage.importantYes();
		addPostPage.tags("Vuk");
		addPostPage.tags("sit");
		addPostPage.content("It is a long established fact that a reader will be distracted by the readable content");
		addPostPage.savePost();
		
		assertEquals(postsListPage.updateMessage(),"New post has been added");
	}
	
	@Test
	public void tc82Home() {
		addPostPage.home();
		
		assertEquals(driver.getCurrentUrl(),"https://testblog.kurs-qa.cubes.edu.rs/admin");
	}
	
	@Test
	public void tc83PostPage() {
		addPostPage.post();
		
		assertEquals(driver.getCurrentUrl(),"https://testblog.kurs-qa.cubes.edu.rs/admin/posts");
	}
	
	@Test
	public void tc84Logout() {
		addPostPage.logout();
		
		assertEquals(driver.getCurrentUrl(),"https://testblog.kurs-qa.cubes.edu.rs/login");
	}

}
